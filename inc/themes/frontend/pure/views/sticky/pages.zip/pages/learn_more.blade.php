@extends('sticky.layout.master')

 

@push('head')
<link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/learn-more.css')}}">
<style>
        .panel-default:hover{
                transform: scale(1.03);
                transition: all .3s ease-in-out;
        }
        .section-header{
    text-align: center;
    color: #320b82;
        }
    </style>
@endpush

@section('page-wrapper')

@include('sticky.layout.partials.common.homeBanner')


@endsection



@section('body')
    <section class="page-section" id="section-features">
					<div class="container">
						<div class="row">
						<!-- Accordion (Features) -->
						<div class="panel-group panel-group__features panel-icon__effect2 col-md-9 mt-2">
							<!-- Panel #1 -->
							    <div class="row">
									   <div class="panel panel-default col-md-6">
								<!-- Panel Heading -->
								<div class="panel-heading box_shadow my-2" role="tab" id="heading4-1">
									<div class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion4" href="#collapse4-1" aria-expanded="false" aria-controls="collapse4-1">
											<div class="row">
												<div class="col-md-3 col-sm-1 col-xs-1 panel-title__number center-content">01</div>
												<div class="col-md-6 col-sm-8 col-xs-9 panel-title__heading center-content">
													<div class="v-center">
														<div class="v-center-inner text-center">
															<div class="hgroup-panel">
																<h3 class='section-header'> {{__('learn_more_account_management')}} </h3>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-sm-2 hidden-xs center-content">
													<div class="circled-icon ">
													    <img src="{{get_theme_frontend_url('assets/sticky/images/Accounts-Management.png')}}" class='img-fluid'>
													</div>
												</div>
												<div class="col-md-12 col-xs-12 panel-title__desc center-content">
													<div class="v-center">
														<div class="v-center-inner text-center">
                                  {{__('learn_more_social')}}
														</div>
													</div>
												</div>
											</div>
										</a>
									</div>
								</div>
							
									   </div>
							<!-- Panel #1 / End -->
	
							<!-- Panel #2 -->
										<div class="panel panel-default col-md-6">
								<!-- Panel Heading -->
								<div class="panel-heading box_shadow my-2" role="tab" id="heading4-2">
									<div class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion4" href="#collapse4-2" aria-expanded="false" aria-controls="collapse4-2">
											<div class="row">
												<div class="col-md-3 col-sm-1 col-xs-1 panel-title__number center-content">02</div>
												<div class="col-md-6 col-sm-8 col-xs-9 panel-title__heading center-content">
													<div class="v-center">
														<div class="v-center-inner text-center">
															<div class="hgroup-panel">
																<h3> {{__('learn_more_team')}} </h3>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-sm-2 hidden-xs center-content">
													<div class="circled-icon ">
													    <img src="{{get_theme_frontend_url('assets/sticky/images/Teammem.png')}}" class='img-fluid'>
													</div>
												</div>
												<div class="col-md-12 col-xs-12 panel-title__desc center-content">
													<div class="v-center">
														<div class="v-center-inner text-center">
                                                      {{__('learn_more_team_member')}}
														</div>
													</div>
												</div>
											</div>
										</a>
									</div>
								</div>
							
										</div>
							<!-- Panel #2 / End -->
	
							<!-- Panel #3 -->
										<div class="panel panel-default col-md-6">
								<!-- Panel Heading -->
								<div class="panel-heading box_shadow my-2" role="tab" id="heading4-3">
									<div class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion4" href="#collapse4-3" aria-expanded="false" aria-controls="collapse4-3">
											<div class="row">
												<div class="col-md-3 col-sm-1 col-xs-1 panel-title__number center-content">03</div>
												<div class="col-md-6 col-sm-8 col-xs-9 panel-title__heading center-content">
													<div class="v-center">
														<div class="v-center-inner text-center">
															<div class="hgroup-panel">
																<h3>{{__('learn_more_storage')}}</h3>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-sm-2 hidden-xs center-content">
													<div class="circled-icon ">
												                 	    <img src="{{get_theme_frontend_url('assets/sticky/images/Reports.png')}}" class='img-fluid'>
												                	</div>
												</div>
												</div>
												<div class="col-md-12 col-xs-12 panel-title__desc center-content">
													<div class="v-center">
											 			<div class="v-center-inner text-center">
                                     {{__('learn_more_own_space')}}
													</div>
												</div>
											</div>
										</a>
									
								</div>
								</div>
							
										</div>
							<!-- Panel #3 / End -->
										<!-- Panel #4 -->
										<div class="panel panel-default col-md-6">
											<!-- Panel Heading -->
											<div class="panel-heading box_shadow my-2" role="tab" id="heading4-4">
												<div class="panel-title">
													<a data-toggle="collapse" data-parent="#accordion4" href="#collapse4-4" aria-expanded="false" aria-controls="collapse4-4">
														<div class="row">
															<div class="col-md-3 col-sm-1 col-xs-1 panel-title__number center-content">04</div>
															<div class="col-md-6 col-sm-8 col-xs-9 panel-title__heading center-content">
																<div class="v-center">
																	<div class="v-center-inner text-center">
																		<div class="hgroup-panel">
																			<h3>   {{__('learn_more_watermark')}} </h3>
																		</div>
																	</div>
																</div>
															</div>
															<div class="col-md-3 col-sm-2 hidden-xs center-content">
																 <div class="circled-icon ">
												                 	    <img src="{{get_theme_frontend_url('assets/sticky/images/copyrights.png')}}" class='img-fluid'>
												                	</div>
															</div>
															</div>
															<div class="col-md-12 col-xs-12 panel-title__desc center-content">
																<div class="v-center">
																	<div class="v-center-inner text-center">
                                                            {{__('learn_more_watermark_2')}}
															</div>
														</div>
														</div>
													</a>
												
											
											</div>
										
										</div>
										</div>
										
										<!-- Panel #4 / End -->
				
										<!-- Panel #5 -->
										<div class="panel panel-default col-md-6">
                                                <!-- Panel Heading -->
                                                <div class="panel-heading box_shadow my-2" role="tab" id="heading4-5">
                                                    <div class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion4" href="#collapse4-5" aria-expanded="false" aria-controls="collapse4-5">
                                                            <div class="row">
                                                                <div class="col-md-3 col-sm-1 col-xs-1 panel-title__number center-content">05</div>
                                                                <div class="col-md-6 col-sm-8 col-xs-9 panel-title__heading center-content">
                                                                    <div class="v-center">
                                                                        <div class="v-center-inner text-center">
                                                                            <div class="hgroup-panel">
                                                                                <h3> {{__('learn_more_reports')}}  </h3>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3 col-sm-2 hidden-xs center-content">
                                                                    <div class="circled-icon ">
												                 	    <img src="{{get_theme_frontend_url('assets/sticky/images/Capacity.png')}}" class='img-fluid'>
												                	</div>
                                                                </div>
                                                                <div class="col-md-12 col-xs-12 panel-title__desc center-content">
                                                                    <div class="v-center">
                                                                        <div class="v-center-inner text-center">
                                                                           {{__('learn_more_month_report')}}
                                                                      </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                              
                                            </div>
										<!-- Panel #5 / End -->
				
										<!-- Panel #6 -->
										<div class="panel panel-default col-md-6">
											<!-- Panel Heading -->
											<div class="panel-heading box_shadow my-2" role="tab" id="heading4-6">
												<div class="panel-title">
													<a data-toggle="collapse" data-parent="#accordion4" href="#collapse4-6" aria-expanded="false" aria-controls="collapse4-6">
														<div class="row">
															<div class="col-md-3 col-sm-1 col-xs-1 panel-title__number center-content">06</div>
															<div class="col-md-6 col-sm-8 col-xs-9 panel-title__heading center-content">
																<div class="v-center">
																	<div class="v-center-inner text-center">
																		<div class="hgroup-panel">
																			<h3>{{__('learn_more_auto')}} </h3>															
																		</div>
																	</div>
																</div>
															</div>
															<div class="col-md-3 col-sm-2 hidden-xs center-content">
																<div class="circled-icon ">
												             	    <img src="{{get_theme_frontend_url('assets/sticky/images/auto-activities.png')}}" class='img-fluid'>
												            	</div>
															</div>
															<div class="col-md-12 col-xs-12 panel-title__desc center-content">
																<div class="v-center">
																	<div class="v-center-inner text-center">
                                                          {{__('learn_more_premium')}}
																</div>
															</div>
														</div>
														</div>
													</a>
												</div>
											</div>
										
										</div>
										<!-- Panel #6 / End -->
											<!-- Panel #7 -->
											<!-- Panel #7 / End -->
										<div class="col-12 text-center">
										    <a href="https://stickyposts.net/stickypost_register/register-en.php?language=2" class="price-btn" style="padding: 3px 25px;font-size: 20px;">Buy Now</a>
										</div>
									</div>
						</div>
						<!-- Accordion (Features) / End -->
	                    <div class="col-sm-12 col-md-6 col-lg-3 mt-3">
                        
                         @include('sticky.layout.partials.common.pdfDownload')
   
                      
                        </div>
                        
				        </div>
				</section>
				 <div class="my-3">
                @include('sticky.layout.partials.common.pricing')
                @include('sticky.layout.partials.common.compare')

        </div>
       @include('sticky.layout.partials.common.reviews')
    
    
    </div><!-- /.page-wrapper -->
    </section>
<!-- POPUP MODAL -->
    <div class="modal fade bd-example-modal-lg" id="response" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content" style="padding: 0px;">
                <div class="modal-header btn-light">
                    <h5 class="modal-title" id="smallmodalLabel">Newsletter Subscribe</h5>
                    <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body text-light text-center" id="get" style="background: #211f1f; padding: 40px;">
                    
                 

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="online" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #200846;color: #fff;">
        <h5 class="modal-title" id="exampleModalLabel"><img src="{{get_theme_frontend_url('assets/sticky/images/logo-W.png')}}" width='50%'></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center" dir='ltr'>
        <h6 style='color:#333'>هذه الخدمة غير متاحه في الوطن العربي وشمال افريقيا </h6>
        <h6 style='color:#333'>ادخل الايميل الخاص بك لاسال التفاصيل </h6>
        <form class="form" method="post">
          <input name="email" class="form-control" id = "email" type="email" placeholder=" ايميل  " title="Your e-mail address is required so I can reply" required maxlength="50" pattern="[^@]+@[^@]+\.[a-zA-Z]{2,6}" >
                <input type="submit" name="submit" class="submit mt-3" value="اشترك !"style="background:#3AB2E5;border:none" />

        </form>
      </div>
    </div>
  </div>
</div>
<!-- model package -->


<!-- Modal -->
<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background:linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);color:#fff">
        <h5 class="modal-title" id="exampleModalLabel">Order larger packages with special privileges</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="form2">

            <div class="form-group">
                <label><span style="color:red">*</span> Full name</label>
                <input type="text" class="form-control" name="fullname">
            </div>
       
            <div class="form-group">
                <label><span style="color:red">*</span> business mail</label>
                <input type="text" class="form-control" name="company_email">
            </div>
       
            <div class="form-group">
                <label><span style="color:red">*</span> Company </label>
                <input type="text" class="form-control" name="company_name">
            </div>
       
            <div class="form-group">
                <label><span style="color:red">*</span> Phone Number </label>
                <input type="Number" class="form-control" name="mobile">
            </div>
       
            <div class="form-group">
                <label><span style="color:red">*</span> Title</label>
                <select class="form-control" name="title" required>
                    <option value="" selected disabled>- Please Select -</option>
                    <option value="Owner">Owner</option>
                    <option value="C-Level">C-Level</option>
                    <option value="Vice President">Vice President</option>
                    <option value="Director">Director</option>
                    <option value="Manager">Manager</option>
                    <option value="Specialist/Coordinator">Specialist/Coordinator</option>
                    <option value="Student">Student</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label><span style="color:red">*</span> Nots</label>
                <textarea class="form-control" name="notice" cols="30" rows="4" placeholder="اكتب ملاحظتك هنا .."></textarea>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-info" >
            </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="mwb_registration_modal">
  <div class="modal-dialog mwb_form_modal modal-dialog-centered">
    <div class="modal-content">
     <button type="button" class="close mwb_close_btn" data-dismiss="modal">&times;</button>
     <div class="modal-body">
       <div class="mwb_registration_form_wrap">
         <h1>registration</h1>
         <span class="mwb_form_icon">
          <img src="{{get_theme_frontend_url('assets/sticky/images/note.png')}}" alt="">
        </span>
        <form class="needs-validation" novalidate>
          <div class="form-row">  
            <div class="col-md-6 mb-3">
              <div class="input-group">
                <input type="text" class="form-control input_form" id="validationRegFirst" placeholder="first name"  required>
                <div class="invalid-feedback">
                  Please enter first name.
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <div class="input-group">
                <input type="text" class="form-control input_form" id="validationRegFirst" placeholder="first name"  required>
                <div class="invalid-feedback">
                  Please enter Last name.
                </div>
              </div>
            </div>
          </div>
          <div class="form-row">  
            <div class="col-md-12 mb-3">
              <div class="input-group">
                <input type="email" class="form-control input_form" id="validationRegEmail" placeholder="email"  required>
                <div class="invalid-feedback">
                  Please enter email.
                </div>
              </div>
            </div>
          </div>
          <div class="form-row">
            <div class="col-md-6 mb-3">
              <div class="input-group">
                <input type="password" class="form-control input_form" id="validationCustomPassword" placeholder="password"  required>
                <div class="invalid-feedback">
                  Please enter password.
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <div class="input-group">
                <input type="password" class="form-control input_form" id="validationConfirmPassword" placeholder="confirm password"  required>
                <div class="invalid-feedback">
                  Please confirm password.
                </div>
              </div>
            </div>
          </div>        
          <div class="mwb_form_btn_wrap">
            <button class="btn btn-primary mwb_form_btn" type="submit">create account</button>
            <p class="mwb-register">
              Already have an account?
              <a href="#" data-toggle="modal" data-target="#mwb_login_modal" data-dismiss="modal">Login!</a>
            </p>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<div aria-live="polite" aria-atomic="true" style="position: relative;">
  <div style="position: fixed;top: 10%;right: 20px;width:300px;">

    <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
      <div class="toast-header">

        <svg width="20" height="20" class="mr-2" viewBox="0 0 24 24">
      <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M11,16.5L18,9.5L16.59,8.09L11,13.67L7.91,10.59L6.5,12L11,16.5Z" fill="#ccc"></path>
    </svg>

        <strong class="mr-auto">Email</strong>
        <small id="time"></small>
        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
      </div>
      <div class="toast-body">
        please Check Your Mail
      </div>
    </div>
  </div>
</div>


@endsection


@push('scripts')


   
@endpush