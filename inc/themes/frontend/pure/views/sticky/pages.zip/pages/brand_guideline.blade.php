@extends('sticky.layout.master')
@push('head')
    <link rel="stylesheet" href="css/style_english.css">
    <link rel="stylesheet" href="css/brand.css">
    <link rel="stylesheet" href="css/mobile-style.css">
    <style>
        .site-header {
            background-image: linear-gradient(-145deg,#320b82 0,#9c33c3 100%) !important;
        }
        @media(max-width:567px){
            .contact-h3{
                font-size:27px!important;
            }
        }
    </style>
@endpush

@section('page-wrapper')
@endsection
@section('body')
  <div class="container my-5">
            <div class="row">
                <div class="col-md-8 mx-auto p-3">
                    <div class="pr-content" itemscope="" itemtype="//schema.org/Article">
                        <div class="pr-story__body margin-top--large margin-bottom--large">
                            <h1 class="pr-header--main pr-font-color--graphite padding-top--small" itemprop="headline">{{__('brand-idh11')}}</h1>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <div class="margin-top--large">
                                    <h2 class="pr-header--small pr-header--small-mobile pr-font-color--graphite" style="text-align: left">{{__('brand-idh21')}}</h2>
                                    <h2 class="pr-header--small pr-header--small-mobile pr-font-color--graphite" style="text-align: left">{{__('brand-idh22')}} </h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <h3 class="pr-header--story">{{__('brand-idh31')}}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <ul class="pr-text--normal pr-text--mobile-small" style="list-style-type: none">
                                    <li class="margin-bottom--base">
                                        <i class="fas fa-play padding-right--medium pr-font-color--blue text--wrap"></i> {{__('brand-idi1')}} 
                                    </li>
                                    <li class="margin-bottom--base">
                                        <i class="fas fa-play padding-right--medium pr-font-color--blue text--wrap"></i>
                                 {{__('brand-idi2')}} 
                                    </li>
                                    <li class="margin-bottom--base">
                                        <i class="fas fa-play padding-right--medium pr-font-color--blue text--wrap"></i>
                                      {{__('brand-idi3')}}  <a href="www.stickyposts.net" rel="noopener noreferrer" target="_blank">www.stickyposts.net</a>.
                                    </li>
                                    <li class="margin-bottom--base">
                                        <i class="fas fa-play padding-right--medium pr-font-color--blue text--wrap"></i>
                                          {{__('brand-idi4')}}  
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content pr-story__body margin-top--large padding-top--large" id="attachments">
                        <div class="flex flex--horizontal flex--space-between margin-bottom--large flex--vertical-mobile">
                            <div class="pr-header--small pr-font-weight--bold margin-bottom--base pr-font-color--graphite">  {{__('brand-iddiv1')}} </div>
                        </div>
                        <div class="pr-text--normal pr-text--mobile-small pr-font-color--graphite"> {{__('brand-iddiv2')}}
                        </div>
                        <div class="flex flex--wrapped">
                            <div class="pr-attachment pr-attachment--half">
                                <div class="pr-border border--dotted margin-bottom--base" style="background: darkmagenta;">
                                    <div class="pr-attachment__image" style="background-image: url('images/logo-1-2.png');">
                                        
                                    </div>
                                </div>
                                <div class="pr-header--xxsmall pr-font-weight--bold pr-font-color--graphite pr-attachment__title margin-bottom--small">{{__('brand-iddiv3')}}
                                </div>
                                <div class="flex flex--horizontal flex--space-between">
                                    <div class="pr-text--xsmall pr-font-color--dark-gray">{{__('brand-iddiv4')}}
                                    </div>
                                    <a class="pr-text--xsmall" download="images/logo-1-2.png" href="images/logo-1-2.png" target="_blank"><i class="ion-ios-cloud-download-outline padding-right--small"></i>{{__('brand-ida1')}}</a>
                                </div>
                            </div>
                            <div class="pr-attachment pr-attachment--half">
                                <div class="pr-border border--dotted margin-bottom--base">
                                    <div class="pr-attachment__image" style="background-image: url('logo-s.png');"></div>
                                    </div>
                                    <div class="pr-header--xxsmall pr-font-weight--bold pr-font-color--graphite pr-attachment__title margin-bottom--small">{{__('brand-iddiv5')}}
                                    </div>
                                    <div class="flex flex--horizontal flex--space-between">
                                        <div class="pr-text--xsmall pr-font-color--dark-gray">{{__('brand-iddiv6')}}
                                        </div>
                                        <a class="pr-text--xsmall" download="www.stickyposts.net/sticky/images/logo-s.png" href="www.stickyposts.net/sticky/images/logo-s.png" target="_blank">
                                            <i class="ion-ios-cloud-download-outline padding-right--small"></i> {{__('brand-iddiv1')}}
                                        </a>
                                    </div>
                                </div>  
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <h2 class="pr-header--small"> {{__('brand-idh23')}}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <div class="pr-text--normal pr-text--mobile-small">{{__('brand-iddiv7')}}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <div class="pr-header--small"> {{__('brand-iddiv8')}}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <ul class="pr-guidelines" style="list-style-type: none">
                                    <li class="pr-guidelines__box">
                                        <div class="pr-guidelines__image pr-border border--dotted sprite-dark-forest" style="background-image: url('https://stickyposts.net/sticky/images/logo-1-1.png');">
                                            
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between">
                                            <div class="pr-text--xsmall">{{__('brand-iddiv9')}}
                                            </div>
                                            <div class="pr-text--xsmall">
                                              {{__('brand-iddiv10')}}
                                            </div>
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between">
                                            <div class="pr-text--xsmall">RGB
                                            </div>
                                            <div class="pr-text--xsmall">22 34 33
                                            </div>
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between">
                                            <div class="pr-text--xsmall">HEX
                                            </div>
                                            <div class="pr-text--xsmall">#162221
                                            </div>
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between margin-bottom--large">
                                            <div class="pr-text--xsmall">Pantone
                                            </div>
                                            <div class="pr-text--xsmall">5467C
                                            </div>
                                        </div>
                                    </li>
                                    <li class="pr-guidelines__box" >
                                        <div style="background: darkmagenta;">
                                            <div class="pr-guidelines__image pr-border border--dotted sprite-dark-forest" style="background-image: url('https://stickyposts.net/sticky/images/logo-1-2.png');">
                                        </div>    
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between">
                                            <div class="pr-text--xsmall">{{__('brand-iddiv9')}}
                                            </div>
                                            <div class="pr-text--xsmall">
                                               {{__('brand-iddiv11')}}
                                            </div>
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between">
                                            <div class="pr-text--xsmall">RGB
                                            </div>
                                            <div class="pr-text--xsmall">255 255 255
                                            </div>
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between">
                                            <div class="pr-text--xsmall">HEX
                                            </div>
                                            <div class="pr-text--xsmall">#fffff
                                            </div>
                                        </div>
                                        <div class="flex flex--horizontal flex--space-between margin-bottom--large">
                                            <div class="pr-text--xsmall">Pantone
                                            </div>
                                            <div class="pr-text--xsmall">5467C
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite">
                            <div class="margin-top--large">
                                <div class="pr-header--small">
                                      {{__('brand-iddiv12')}}</div>
                            </div>
                        </div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite"><div class="margin-top--large"><div class="pr-text--normal pr-text--mobile-small">{{__('brand-iddiv13')}}</div></div></div></div></div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite"><div class="margin-top--large"><img class="pr-story-element__image" src="https://stickyposts.net/sticky/images/logo-1-1.png"></div></div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite"><div class="margin-top--large"><div class="pr-header--small">Icon Spaces Guidelines:- {{__('brand-iddiv14')}}</div></div></div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite"><div class="margin-top--large">
                            <div class="pr-text--normal pr-text--mobile-small">
                        {{__('brand-iddiv15')}}    
                        </div>
                        </div></div>
                    </div>
                    <div class="pr-content">
                        <div class="pr-story__body margin-top--large pr-font-color--graphite"><div class="margin-top--large">
                            <img class="pr-story-element__image" src="https://stickyposts.net/sticky/logo-s.png"></div></div>
                    </div>
                    <div class="pr-content mt-4" style="background: linear-gradient(-145deg,#320b82 0,#9c33c3 100%);color: #fff;padding: 20px 30px;">
                        <h3 class="contact-h3" style="margin-bottom: 25px;font-size: 32px;text-align: center;">  {{__('brand-idh32')}} </h3>
                        <p> {{__('brand-idp1')}}</p>
                        <h3>
                        {{__('brand-idh33')}}
                        </h3>
                        <p style="margin: 0;">Marketing@stickyposts.net</p>
                        <p> {{__('brand-idp2')}}</p>
                        <form class="form-redirect">
                            <input hidden value='en' name="lang">
                            <div class="row">
                        
                                <div class="col-md-6">
                                    <label style="margin: 0;"> <span style="color:red">*</span>{{__('cont-idlab1')}}</label>
                                    <input type="text" name="fname" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label style="margin: 0;"> <span style="color:red">*</span>{{__('cont-idlab2')}}</label>
                                    <input type="text" name="lname" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label style="margin: 0;"> <span style="color:red">*</span>{{__('cont-idlab3')}}</label>
                                    <input type="email" name="email" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label style="margin: 0;"> <span style="color:red">*</span>{{__('cont-idlab4')}}</label>
                                    <input type="number" name="phone" class="form-control">
                                </div>
                                <div class="col-md-12">
                                    <label style="margin: 0;"> <span style="color:red">*</span>{{__('cont-idlab7')}}</label>
                                    <textarea class="form-control" id="message_contact1" rows="5" name="msg" required></textarea>
                                    <input type="hidden" name="type" value="brandguid">
                                </div>
                                <div class="col-md-12">
                                    <label style="margin: 0;font-size:11px;"> ( <span style="color:red">*</span> )  {{__('brand-idlabel1')}}</label>  
                                </div>
                                <div class="col-md-4 mt-5 subscribe_form" style="box-shadow:0 0 0 0;">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="submit" name="" style="border-radius: 3px;width:100%;font-size:21px;"> {{__('brand-idbtn1')}}</button>
                                </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
@endsection
 <script>
 $('.form-redirect').submit(function(e){
	        $('.loader').modal('show');
            $('.lds-ring').show();
            $('.modal-body').html('....');
	        e.preventDefault();
	        
	        $.ajax({
	          url:    'contact-ajax.php',
	          method:   'POST',
	          dataType:   'text',
	          data:   $(this).serialize() ,
	          success : function(response)
	             {
                //     $('.lds-ring').hide();
	               // $('.modal-body').html(response);
	                 
	                 if(~response.indexOf('activation')){
                        var om_elresponse = response.substring(11, response.length);
                        var resend_link = '<a href="#" class="resend_active" data-email="'+ om_elresponse +'" onclick="resend_activation(\''+ om_elresponse +'\', \'contactus\')"> Resend activation e-mail </a>';    
                    
                        
                        $('.lds-ring').hide();
                        
                        $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will receive an email </h5><h5 style='color:#fff;line-height: 1.8;'> to confirm your email address</h5>" + resend_link);
                    }
                    else if(~response.indexOf('acti7ation')){
                        var om_elresponse = response.substring(11, response.length);
                        var resend_link = '<a href="#" class="resend_active" data-email="'+ om_elresponse +'" onclick="resend_activation(\''+ om_elresponse +'\', \'contactus\')"> Resend activation e-mail </a>';    
                    
                       $('.lds-ring').hide();
                       $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists but not verified </h5><h5 style='color:#fff;line-height: 1.8;'>please verify your mail in order to send your request</h5>" + resend_link);
                    }

                    else if (response == 'exists000'){
                    
                       $('.lds-ring').hide();
                       $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists </h5><h5 style='color:#fff;line-height: 1.8;'>we already recieved your request.</h5>");
                        
                    }
	                 
	                 
	             }
	        });
	        
	      $('.loader').modal('show');
	        
	      });
    function lang1() {
        location.assign("https://stickyposts.net/sticky/Brand_guideline-Ar.php" + lang_url_params)
    }
  function lang2() {
        location.assign("https://stickyposts.net/sticky/Brand_guideline-Fr.php" + lang_url_params)
    }

</script>

@push('scripts')


@endpush