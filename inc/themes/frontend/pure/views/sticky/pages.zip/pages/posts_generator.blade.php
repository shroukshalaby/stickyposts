@extends('sticky.layout.master')
@push('head')
    <link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/replay_en.css')}}">
    <link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/postGenerator.css')}}">
    </head>
    <style>
        .IMAGES2 {
            position: absolute;
            left: 2%;
            bottom: 48%;
            width: 10%;
        }

        @media (max-width: 567px) {
            .single-pricing-one {
                width: 240px !important;
                height: 335px !important;
                margin: 10px auto;
            }

            @media (min-width: 1200px) {
                .highlights-phone.wht .phone-holder #fon {
                    background-position-x: -29px;
                    background-position-y: 23px;
                }
            }
    </style>
@endpush
@section('page-wrapper')

@endsection
@section('body')
    <div class="page-wrapper">
        <section class="banner-style-one home-page-two" id="banner" style="position:relative">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-8 col-12 text-center hide-mobile">
                        <!--<img src="images/logo-1-2.png" alt="Awesome Image" width="" style=""/>-->
                        <div class="content-block">

                            <h4 style="color:#fff;margin:0">{{__('gen-des')}} </h4>
                            <h3 style="font-size: 1.7rem !important;">{{__('gen-soc')}}</h3>
                            <h3 style="font-size: 1.55rem !important;margin-bottom:10px">{{__('gen-one')}}
                                @switch($ipData['geoplugin_countryName'])
                                    @case('Egypt')
                                    99 L.E
                                    @break
                                    @case('United Arab Emirates')
                                    23 AED
                                    @break
                                    @case('Saudi Arabia')
                                    24 Riyal
                                    @break
                                    @default
                                    6$
                                @endswitch
                            <div class="subform mb-2">
                                <form id="signup" class="formee signuptrial"
                                      style='display: flex;justify-content: center;' method="post">
                                    <input class="right inputnew" style='border-radius: 5px 0px 0px 5px;' type="submit"
                                           title="Send" value="Start FREE trial"/>
                                    <input type="hidden" value="postGeneratorPage" name="type">
                                    <input name="email" id="email" style='border-radius: 0px 5px 5px 0px;' type="email"
                                           placeholder="{{__('gen-mail')}}"
                                           pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required/>
                                </form>
                            </div>
                            <div class="form-note">
                                <p style="color:#fff;margin:0 0 3px;">{{__('gen-3')}}</p>
                                <p style="color:#fff;line-height: 1;">{{__('gen-cancel')}}</p>
                            </div>
                        </div><!-- /.content-block -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-7 col-md-8 col-12 text-left view-mobile">
                        <!--<img src="images/logo-1-2.png" alt="Awesome Image" width="" style=""/>-->
                        <div class="content-block">

                            <h3 style="font-size: 2.4rem !important; font-weight:900 ;margin:0">{{__('gen-man')}} </h3>
                            <h4 style="color:#fff;margin:0;font-size: 1.55rem;">{{__('gen-Design')}} </h4>
                            <h3 style="font-size: 1.55rem !important;margin:0;"> {{__('gen-from')}} <span
                                        style="font-weight:bold">
                                        @switch($ipData['geoplugin_countryName'])
                                        @case('Egypt')
                                        99 L.E
                                        @break
                                        @case('United Arab Emirates')
                                        23 AED
                                        @break
                                        @case('Saudi Arabia')
                                        24 Riyal
                                        @break
                                        @default
                                        6$
                                    @endswitch
                                </span>{{__('gen-monthly')}}</h3>
                            <div class="subform my-2">
                                <a class="submit"
                                   href="https://stickyposts.net/stickypost_register/register-en.php?language=2"
                                   style='padding: 5px 15px;font-size: 1.5rem '> {{__('gen-start')}}</a>

                            </div>
                            <div style="margin-top: .6rem;font-size: .9rem; font-weight: 700">
                                <a href="https://stickyposts.net/sticky/payment.php" id="compar"
                                   style="color:#fff; text-decoration: underline;"> {{__('gen-comp')}}  </a>
                            </div>
                            <div class="form-note">
                                <p style="color:#fff;margin:0 0 3px;font-size: 1rem "> {{__('gen-cred')}}</p>
                                <p style="color:#fff;line-height: 1;margin:0 0 3px;font-size: 1rem ">{{__('gen-cancel')}}</p>
                            </div>
                        </div><!-- /.content-block -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.banner-style-one -->
        <div class="client-section">
            <div class="container text-center">
                <div class="clients">
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client1.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client1-c.png" class="color" alt="Client"/>
                    </div>
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client3.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client3-c.png" class="color" alt="Client"/>
                    </div>
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client5.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client5-c.png" class="color" alt="Client"/>
                    </div>
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client6.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client6-c.png" class="color" alt="Client"/>
                    </div>
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client4.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client4-c.png" class="color" alt="Client"/>
                    </div>
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client2.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client2-c.png" class="color" alt="Client"/>
                    </div>
                    <div class="single">
                        <img src="https://stickyposts.net/sticky/images/client7.png" class='none' alt="Client"/>
                        <img src="https://stickyposts.net/sticky/images/client7-c.png" class="color" alt="Client"/>
                    </div>
                </div>
            </div>
        </div>
        <div class="container T-container">
            <div class="row justify-content-between align-items-center">
                <div class="col-lg-7 col-md-7 col-sm-6 order-lg-1 order-md-1 order-2 d-lg-block d-md-block d-none">
                    <div class="text-center">
                        <h2 style="color:#320b82">{{__('gen-Gen')}} </h2>
                        <h4 class="section-head" style="font-size:1.3rem">{{__('gen-Create')}} <span
                                    style="font-weight:bold">{{__('gen-free')}}</span>
                        </h4>

                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-6 order-lg-1 order-md-1 order-2 d-lg-none d-md-none d-block">
                    <div class="text-center">
                        <h2 style="color:#320b82">{{__('gen-Gen')}} </h2>
                        <h4 class="section-head" style="font-size:1.3rem">{{__('gen-create2')}}</h4>

                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-sm-6 order-lg-2 order-md-2 order-1">
                    <img class="img-fluid" src="{{get_theme_frontend_url('assets/sticky/images/dashboard/MultiDevicesWebsiteMockups.png')}}">
                </div>
            </div>

            <div class="row " id="benefits">
                <div class="col-12 text-center">
                    <h2 style="color:#320b82 ;font-size:2rem">{{__('gen-ben')}}</h2>
                </div>
                <div class="col-sm-6 col-md-5 col-lg-3 my-auto">
                   @include('sticky.layout.partials.common.pdfDownload')
                </div>
                <div class="col-sm-6 col-md-7 col-lg-9  hide-mobile">
                    <div id="features" class="section wb">
                        <div class="container">

                            <div id="default" class="row clearfix zenith_slider p-0">

                                <!--The First row-->
                                <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 pr-0 left-row">
                                    <ul class="features-left"
                                        style='justify-content: center;display: flex;flex-direction: column;height: 100%;'>
                                        <li class="highlight lhgh" data-index="0">
                                            <img src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/Create.png')}}">
                                            <div class="fl-inner">
                                                <h4>{{__('gen-c')}} </h4>
                                                <p>{{__('gen-plat')}}</p>
                                            </div>
                                        </li><!-- .highlight .left-row -->

                                        <li class="highlight lhgh" data-index="1">
                                            <img src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/Choose.png')}}">
                                            <div class="fl-inner">
                                                <h4>{{__('gen-choose')}}</h4>
                                                <p>{{__('gen-unlim')}}</p>
                                            </div>
                                        </li><!-- .highlight .left-row -->
                                        <li class="highlight lhgh" data-index="2">
                                            <img src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/Upload.png')}}">
                                            <div class="fl-inner">
                                                <h4>{{__('gen-up')}}</h4>
                                                <p>{{__('gen-mater')}}</p>
                                            </div>
                                        </li><!-- .highlight .left-row -->

                                    </ul>
                                </div><!-- .row .left-row -->

                                <div class="highlights-phone col-lg-4 col-md-4 col-sm-12 col-xs-12 wht">

                                    <div class="phone-holder">
                                        <div id="fon"></div>
                                        <div class="hgh-linner hgi" data-index="0">
                                            <img width="190" height="320" src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/phone/Create.jpg')}}"
                                                 class="attachment-highlight wp-post-image" alt="screen"/>
                                        </div>
                                        <div class="hgh-linner hgi" data-index="1">
                                            <img width="234" height="398" src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/phone/CHOOSE.jpg')}}"
                                                 class="attachment-highlight wp-post-image" alt="screensdst"/>
                                        </div>
                                        <div class="hgh-rinner hgi" data-index="2">
                                            <img width="234" height="398" src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/phone/upload.jpg')}}"
                                                 class="attachment-highlight wp-post-image" alt="screen_08"/>
                                        </div>
                                        <div class="hgh-rinner hgi" data-index="3">
                                            <img width="234" height="398"
                                                 src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/phone/Best results.jpg')}}"
                                                 class="attachment-highlight wp-post-image" alt="screen_06"/>
                                        </div>
                                        <div class="hgh-rinner hgi" data-index="4">
                                            <img width="234" height="398"
                                                 src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/phone/Unlimited users.jpg')}}"
                                                 class="attachment-highlight wp-post-image" alt="screen_06"/>
                                        </div>
                                        <div class="hgh-rinner hgi" data-index="5">
                                            <img width="234" height="398" src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/phone/share.jpg')}}"
                                                 class="attachment-highlight wp-post-image" alt="screen_06"/>
                                        </div>
                                    </div>
                                </div>

                                <!--The Second row-->
                                <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 pl-0 right-row T-p-0">
                                    <ul class="features-right"
                                        style='justify-content: center;display: flex;flex-direction: column;height: 100%;'>
                                        <li class="highlight rhgh" data-index="3">
                                            <img src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/best-Results.png')}}">
                                            <div class="fr-inner">
                                                <h4>{{__('gen-Best')}}</h4>
                                                <p>{{__('gen-edit')}}</p>
                                            </div>
                                        </li><!-- .highlight .left-row -->
                                        <li class="highlight rhgh" data-index="4">
                                            <img src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/unlimited-users.png')}}">
                                            <div class="fr-inner">
                                                <h4>{{__('gen-use')}}</h4>
                                                <p>{{__('gen-add')}}</p>
                                            </div>
                                        </li><!-- .highlight .left-row -->
                                        <li class="highlight rhgh" data-index="5">
                                            <img src="{{get_theme_frontend_url('assets/sticky/images/mobileslider/Share.png')}}">
                                            <div class="fr-inner">
                                                <h4>{{__('gen-sh')}}</h4>
                                                <p>{{__('gen-pub')}}</p>
                                            </div>
                                        </li><!-- .highlight .left-row -->
                                    </ul>
                                </div><!-- .row .left-row -->

                            </div><!--Highlights close-->
                        </div><!-- end container -->
                    </div><!-- end section -->

                </div>
            </div>
        </div>
        <section class="pricing-style-one home-page-two d-block mt-1" id="pricing"
                 style="transform: rotate(180deg);background:linear-gradient(90deg, #320b82 0%, #9c33c3 100%);padding:25px 0 20px">
            <div class="container-fluid" style="transform: rotate(180deg);">
                <div class="block-title text-center text-light">
                    <h4 style="color:#fff">{{__('gen-need')}}</h4>
                </div><!-- /.block-title -->
                <div class='row p-0 justify-content-center'>
                    <div class="col-sm-4 col-md-4 col-lg-2 p-1">
                        <div class="single-pricing-one pro-pack" class="card-height">
                            <div class="top-block" style="direction: ltr;">
                                <h2>{{__('gen-Gen')}} </h2>
                            </div><!-- /.top-block -->
                            <ul class="feature-lists text-left" style="height: 175px;padding-top: 10%;">
                                <li><span style="color:#f00">*</span> {{__('gen-eas')}}</li>
                                <li><span style="color:#f00">*</span> {{__('gen-opt')}}</li>
                                <li><span style="color:#f00">*</span> {{__('gen-brand')}} </li>
                                <li><span style="color:#f00">*</span> {{__('gen-want')}} </li>
                                <li><span style="color:#f00">*</span> {{__('gen-users')}}</li>
                                <li><span style="color:#f00">*</span> {{__('gen-use-des')}} </li>
                                <li><span style="color:#f00">*</span> {{__('gen-final')}} </li>
                            </ul><!-- /.feature-lists text-right -->
                            <div class="bottom-block">

                                <a href="https://stickyposts.net/stickypost_register/register.php?language=1"
                                   class="price-btn" style="cursor: pointer;">{{__('gen-gin')}}</a>
                                <h5 class="tag-line text-center"> {{__('gen-nf')}}<br> {{__('gen-cancel')}}    </h5>
                                <p> {{__('gen-3f')}} </p>
                            </div><!-- /.bottom-block -->
                        </div><!-- /.single-pricing-one -->
                    </div>
                </div>
                <div class="container-fluid hide-mobile">

                    @include('sticky.layout.partials.common.compare')

                </div>
            </div>
        </section><!-- /.pricing-style-one -->
        <div class="modal fade loaders bd-example-modal-lg" tabindex="-1" role="dialog"
             aria-labelledby="exampleModalLabel" aria-hidden="true"
             style="background: rgba(0, 0, 0, 0.7); padding-top: 60px;">
            <div class="modal-dialog miniDialog" role="document">
                <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
                <!--    <span aria-hidden="true">&times;</span>-->
                <!--  </button>-->
                <div class="modal-content" style="background: linear-gradient(275deg, #5e2298, #320b82);color:#fff">
                    <div class="modal-header pl-2 p-1">
                        <img src="logo-s.png" style="width: 49px;z-index: 10;">

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                style="position: absolute;top: 12px;right: 18px;">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div id="modal-body" class="text-center">
                        <div class="lds-ring">
                            <img src="logo-s.png')}}">
                        </div>

                        <div class="modal-body" style="padding:0 16px"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hide-mobile">
            @include('sticky.layout.partials.common.reviews')
        </div>
    </div><!-- /.page-wrapper -->
    <div class="modal fade bd-example-modal-lg" id="myModal" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalLabel" aria-hidden="true"
         style="background: rgba(0, 0, 0, 0.7); padding-top: 60px;">
        <div class="modal-dialog miniDialog" role="document">
            <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
            <!--    <span aria-hidden="true">&times;</span>-->
            <!--  </button>-->
            <div class="modal-content" style="background: linear-gradient(275deg, #5e2298, #320b82);color:#fff">
                <div class="modal-header pl-2 p-1">
                    <img src="logo-s.png" style="width: 49px;z-index: 10;">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            style="position: absolute;top: 12px;right: 18px;">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>

                <div id="modal-bodyres" class="text-center" style="margin: 10px 0;">
                    <h3 style=' color:#fff' class='text-center'> Get Resources <span
                                style="color:#f9c412; font-weight:bold">free </span></h3>
                    <div class="row my-row m-0 px-2">
                        <div class="col-sm-7">
                            <div class="page-links nav nav-pills mb-4" id="pills-tab" role="tablist">
                                <a id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab"
                                   aria-controls="pills-home" aria-selected="true"
                                   class="ml-auto mr-3 model-tabs active">{{__('gen-log')}}</a>

                                <a id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab"
                                   aria-controls="pills-profile" aria-selected="false"
                                   class='mr-3 model-tabs '>{{__('gen-reg')}}</a>
                            </div>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                     aria-labelledby="pills-home-tab">
                                    <form style="direction:ltr" class="login" method="post">

                                        <input type="hidden" name="lang" value="en">
                                        <input type="hidden" name="page" value="">

                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>{{__('gen-mail')}}</label>
                                            <div class="col-8">
                                                <input type="email" class="form-control" name="mail"
                                                       style="height: 24px;"
                                                       pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>{{__('gen-pass')}}</label>
                                            <div class="col-8">
                                                <input type="password" class="form-control" name="pass"
                                                       style="height: 24px;" required>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0  row  mt-3 text-center"
                                             style='display: flex;justify-content: center;align-items: center; flex-direction: column;'>
                                            <button class="submit mb-0 ml-0" type="submit" name="login"
                                                    style='height: 35px;border-radius: 5px; font-size: 1.5rem;font-weight: 600;background: #f9c412 !important;color: #320b82;"'
                                                    name="login" id="sub"> {{__('gen-gin')}} </button>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                     aria-labelledby="pills-profile-tab">
                                    <form style="direction:ltr" class="formres" method="post">
                                        <input type="hidden" name="lang" value="en">
                                        <input type="hidden" name="page" value="<?php echo $page4599;?>">
                                        <div class="form-group row mb-1  ml-auto">
                                            <label class="col-4 p-0" style="margin: 0;font-size:12px"> <span
                                                        style="color:red">*</span>{{__('gen-fn')}}</label>
                                            <div class="col-8">
                                                <input type="text" class="form-control" name="fn7" required
                                                       style="height: 24px;">
                                            </div>

                                        </div>
                                        <div class="form-group row mb-1  ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size:12px"> <span
                                                        style="color:red">*</span>{{__('gen-ln')}}</label>
                                            <div class="col-8">
                                                <input type="text" class="form-control" name="ln7" required
                                                       style="height: 24px;">
                                            </div>

                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>{{__('gen-mail')}}</label>
                                            <div class="col-8">
                                                <input type="email" class="form-control" name="em7"
                                                       style="height: 24px;"
                                                       pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>{{__('gen-pass')}}</label>
                                            <div class="col-8">
                                                <input type="password" class="form-control" name="pass"
                                                       style="height: 24px;" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 10px;"> <span
                                                        style="color:red">*</span> {{__('gen-cpass')}} </label>
                                            <div class="col-8">
                                                <input type="password" class="form-control" name="Cpass"
                                                       style="height: 24px;" required>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0  row  mt-3 text-center"
                                             style='display: flex;justify-content: center;align-items: center; flex-direction: column;'>
                                            <button class="submit mb-0 ml-0" type="submit" name="signin"
                                                    style='height: 35px;border-radius: 5px; font-size: 1.5rem;font-weight: 600;background: #f9c412 !important;color: #320b82;"'
                                                    name="submit" id="sub"> {{__('gen-gin')}} </button>
                                        </div>
                                    </form>
                                    location
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-5 pl-0 text-center"
                             style="display: flex;justify-content: center;align-items: center;">
                            <img src="{{get_theme_frontend_url('assets/sticky/images/rescopopup.png')}}" style="width: 192px">

                        </div>
                    </div>
                    <div style="display:flex;justify-content: space-between;">
                        <small class='text-left' style="font-size:10px ;margin-left:15px">* {{__('gen-safe')}} </small>
                        <small class='text-right' style="font-size:10px ;margin-right:15px"><span
                                    style="color:#f00">*</span> {{__('gen-req')}} </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    @include('sticky.layout.partials.popups')
@endpush
