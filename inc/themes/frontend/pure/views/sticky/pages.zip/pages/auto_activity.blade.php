@extends('sticky.layout.master')
@push('head')

@endpush
@section('page-wrapper')
@endsection

    @section('body')
    @include('sticky.layout.partials.common.autoActivityBanner')
        
      <div class="page-wrapper">
        <div class="section-2 p-0 mt-2 text-left" id="benefits">
            <div class="block-title text-center">
                    <h2> {{__('rep-adv')}} </h2>
                </div><!-- /.block-title -->
            <div class="container">
                <div class="row index-row box_shadow mt-2 hide-mobile "> 
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0">
                                <img src="images/autoactivity/multiple accounts.png" class="img-fluid">
                            </div>
                            <div class="col-9 p-0 m-auto">
                                <div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-manage')}} </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/track automatically.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-auto')}} </div></div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/react Account.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-ability')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/Desired accounts interact.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-select')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/follow you.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-select-acc')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/react Account.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-identify')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/comment on your photos.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-identify-act')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"> <img src="images/autoactivity/100 reactions.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-swift')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/Filter.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-filter')}} </div></div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/Blocking.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-possibility')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/On-Off.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-auto-act')}} </div></div>
                        </div>
                        
                    </div>
                    <div class="col-md-3 col-sm-4 mb-2">
                        <div class="row">
                            <div class="col-3 p-0"><img src="images/autoactivity/features.png" class="img-fluid"></div>
                            <div class="col-9 p-0 m-auto"><div class="more" style="font-size: 14px;padding-left: 6px;"> {{__('rep-more-30')}} </div></div>
                        </div>
                        
                    </div>
                </div>
                <div class="view-mobile">
        	        <div class="row w-75 mx-auto">
        	<div class=" col-12">
                <div class="item" dir="ltr">
                    <img src="images/replay/increase-Clients.jpg" class="img-fluid">
                    <div class="about" >
                    <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700"> {{__('rep-cust-base')}} </p>
                    <div class="caption"style="font-size: 1.2rem;line-height: 1.5;"> {{__('rep-designed')}} </div>
                   </div>
                </div>
            </div>
            <div class=" col-12">
                <div class="item" dir="ltr">
              
                    <img src="images/replay/reports.jpg" class="img-fluid">
                    <div class="about"  >
                    <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700"> {{__('rep-detailed')}} </p>
                    <div class="caption"style="font-size: 1.2rem;line-height: 1.5;">  {{__('rep-enable')}} </div>
                   </div>
                  
                  
                </div>
            </div>
            <div class=" col-12">
                <div class="item" dir="ltr">
            	<img src="images/replay/Schadule.jpg" class="img-fluid">
            	 <div class="about"  >
                    <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700"> {{__('rep-auto-sch')}}  </p>
                    <div class="caption"style="font-size: 1.2rem;line-height: 1.5;"> {{__('rep-it-makes')}} </div>
                   </div>
                </div>
            </div> 
            <div class=" col-12">
                <div class="item" dir="ltr" style="position:relative;">
                  
                  <img src="images/replay/Competitors.jpg" class="img-fluid">
                   <div class="about"  >
                    <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700"> {{__('rep-team-mem')}} </p>
                    <div class="caption"style="font-size: 1.2rem;line-height: 1.5;"> {{__('rep-fast')}} </div>
                    </div>
               
                </div>
            </div> 
        	</div>
        	    </div>
            </div>
        </div>
        <div class="container T-container">
            <div class="text-center">
                    <h4 class="section-head hide-mobile mt-3"  style="color:#320b82; font-size:2.5rem" > {{__('rep-auto-ben')}} </h4>
                    <h4 class="view-mobile mb-4" style="color:#320b82;font-weight:bold ;" > {{__('rep-report')}} </h4>
                </div>
                    <div class="row " id="benefits">
                        <div class="col-sm-6 col-md-5 col-lg-3 my-auto">
                               @include('sticky.layout.partials.common.pdfDownload')
                        </div>
                        <div class="col-sm-6 col-md-7 col-lg-9  hide-mobile">
                    	<div id="features" class="section wb">
                            <div class="container">
                                <div id="default" class="row clearfix zenith_slider p-0">
                                      
                    				<!--The First row-->  
                    				<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 pr-0 left-row">
                    					<ul class="features-left" style='justify-content: center;display: flex;flex-direction: column;height: 100%;'>
                    						<li class="highlight lhgh" data-index="0">
                    							<img src="images/mobileslider/Increase-Clients.png">
                    							<div class="fl-inner">
                    								<h4> {{__('rep-cust-base')}} </h4>
                    								<p> {{__('rep-designed')}} </p>
                    							</div>
                    						</li><!-- .highlight .left-row -->
                    
                    						<li class="highlight lhgh" data-index="1">
                    							<img src="images/mobileslider/Reports.png">
                    							<div class="fl-inner">
                    								<h4> {{__('rep-detailed')}} </h4>
                    								<p> {{__('rep-enable')}} </p>
                    							</div>
                    						</li><!-- .highlight .left-row -->
                    
                    					</ul>
                    				</div><!-- .row .left-row -->
                    			  
                    				<div class="highlights-phone col-lg-4 col-md-4 col-sm-12 col-xs-12 wht">
                    				  
                    					<div class="phone-holder">
                    					   <div id="fon"></div>
                    					   <div class="hgh-linner hgi" data-index="0">
                    							<img width="190" height="320" src="images/mobileslider/phone/increase-Clients.png" class="attachment-highlight wp-post-image" alt="screen" />    
                    						</div>
                    						<div class="hgh-linner hgi" data-index="1">
                    							<img width="234" height="398" src="images/mobileslider/phone/reports.png" class="attachment-highlight wp-post-image" alt="screensdst" />    
                    						</div>
                    						<div class="hgh-rinner hgi" data-index="2">
                    							<img width="234" height="398" src="images/mobileslider/phone/Scadule.png" class="attachment-highlight wp-post-image" alt="screen_08" />    
                    						</div>
                    						<div class="hgh-rinner hgi" data-index="3">
                    							<img width="234" height="398" src="images/mobileslider/phone/Team.png" class="attachment-highlight wp-post-image" alt="screen_06" />    
                    						</div>
                    					</div>
                    				</div>
                    
                    				<!--The Second row-->
                    				<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 pl-0 right-row T-p-0">
                    					<ul class="features-right" style='justify-content: center;display: flex;flex-direction: column;height: 100%;'>
                    						<li class="highlight rhgh" data-index="2">
                    							<img src="images/mobileslider/Schadule.png">
                    							<div class="fr-inner">
                    								<h4> {{__('rep-auto-sch')}} </h4>
                    								<p> {{__('rep-it-makes')}} </p>
                    							</div>
                    						</li><!-- .highlight .left-row -->
                    						<li class="highlight rhgh" data-index="3">
                    							<img src="images/mobileslider/Team.png">
                    							<div class="fr-inner">
                    								<h4> {{__('rep-team-mem')}} </h4>
                    								<p> {{__('rep-fast')}} </p>
                    							</div>
                    						</li><!-- .highlight .left-row -->
                    					</ul>
                    				</div><!-- .row .left-row -->
                    			  
                    			</div><!--Highlights close-->
                            </div><!-- end container -->
                        </div><!-- end section -->

                        </div>
                    </div>
                </div>
        <section class="pricing-style-one home-page-two remove-bg" id="pricing" style="transform: rotate(180deg);background:linear-gradient(270deg, #320b82 0%, #9c33c3 100%)!important;padding:25px 0 20px">
            <div class="container-fluid hide-mobile" style="transform: rotate(180deg);">
                <div class="block-title text-center text-light">
                    <h4 style="color:#fff"> {{__('rep-choose')}} </h4>
                </div><!-- /.block-title -->
                <ul class="nav nav-tabs tab-title my-2" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" href="#yearly" role="tab" data-toggle="tab"> {{__('rep-year')}} </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#monthly" role="tab" data-toggle="tab"> {{__('rep-month')}} </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane show active" id="monthly">
                        <div class="" style="w-100">
                                <div class='row m-auto p-0 justify-content-center'>
                                    
                                    <div class="col-sm-4 col-md-4 col-lg-2 p-1"  >
                                        
                                <div class="single-pricing-one">
                                    <div class="top-block" style="direction: ltr;">
                                        <h2> {{__('rep-econ')}} </h2>
                                               <p class="price m-0" style="direction: rtl;"><?php if ($location == 'Egypt' ){echo '75 EGP';}elseif ($location == 'United Arab Emirates'){echo '18 Dirham';}
                                               elseif ($location == 'Saudi Arabia'){echo '18 Riyal';}
                                               else {echo '5$';} ?></P>
 
                                        <div class="line"></div><!-- /.line -->
                                    </div><!-- /.top-block -->
                                    <ul class="feature-lists text-left">
                                        <li><span style="color:#f00">*</span> {{__('rep-man-up')}} <span style="font-weight:bold;font-size:16px">7</span></li>
                                        <li><span style="color:#f00">*</span> {{__('rep-unlim')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-up-to-50')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-property')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-reports')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-auto-a')}} <span style="padding:5px;color:#f00"> {{__('rep-extra')}} </span></li>
                                    </ul><!-- /.feature-lists text-left -->
                                    <div class="bottom-block bottom-blocks">
                                        <a href="learn-moreen.php"> {{__('rep-learn')}} </a>
                                        <a href="../stickypost_register/register-en.php?language=2" class="price-btn" style="cursor: pointer;"> {{__('rep-buy')}} </a>
                                        <h5 class="tag-line text-center"> {{__('rep-no-fees')}} <br> {{__('rep-cancel')}} </h5>
                             <p> {{__('rep-free-trial')}} </p>
                                    </div><!-- /.bottom-block -->
                                </div><!-- /.single-pricing-one -->
                                    </div> 
                                    <div class="col-sm-4 col-md-4 col-lg-2 p-1"  >
                                    <div class="single-pricing-one pro-pack">
                                    <div class="top-block" style="direction: ltr;">
                                        <h2> {{__('rep-special')}} </h2>
                                                   <p class="price m-0" style="direction: rtl;"><?php if ($location == 'Egypt' ){echo '150 EGP';}elseif ($location == 'United Arab Emirates'){echo '35 Dirham';}
                                                   elseif ($location == 'Saudi Arabia'){echo '36 Riyal';}
                                                   else {echo '10$';} ?></P>
 
                                        <div class="line"></div><!-- /.line -->
                                    </div><!-- /.top-block -->
                                    <ul class="feature-lists text-left">
                                        <li><span style="color:#f00">*</span> {{__('rep-man-up')}} <span style="font-weight:bold;font-size:16px">14</span></li>
                                        <li><span style="color:#f00">*</span> {{__('rep-unlim')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-up-to-50')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-property')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-reports')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-auto-a')}} <span style="padding:5px;color:#f00"> {{__('rep-extra')}} </span></li>
                                        <li><span style="color:#f00">*</span> {{__('rep-adding-mult')}} <span style="padding:5px;color:#f00"> {{__('rep-extra')}} </span></li>
                                    </ul><!-- /.feature-lists text-left -->
                                    <div class="bottom-block">
                                        <a href="learn-moreen.php"> {{__('rep-learn')}} </a>
                                        <a href="../stickypost_register/register-en.php?language=2" class="price-btn" style="cursor: pointer;"> {{__('rep-buy')}} </a>
                                        <h5 class="tag-line text-center"> {{__('rep-no-fees')}} <br> {{__('rep-cancel')}} </h5>
                                        <p> {{__('rep-free-trial')}} </p>
                                    </div><!-- /.bottom-block -->
                                </div><!-- /.single-pricing-one -->
                                    </div> 
                                </div>
                            
 
                          </div>  

                    </div><!-- /.tab-pane -->
                    <div role="tabpanel" class="tab-pane" id="yearly">
                        <div class="" style="">
                            
                                <div class='row m-auto p-0 justify-content-center'>
                                    
                                    <div class="col-sm-4 col-md-4 col-lg-2 p-1"  >
                                        
                                <div class="single-pricing-one">
                                    <div class="top-block" style="direction: ltr;">
                                        <h2> {{__('rep-econ')}} </h2>
                                           <p class="price m-0" style="direction: rtl;"><?php if ($location == 'Egypt' ){echo '792 EGP';}
                                           elseif ($location == 'United Arab Emirates'){echo '185 Dirham';}
                                           elseif ($location == 'Saudi Arabia'){echo '191 Riyal';}
                                           else {echo '51$';} ?></P>

                                        <div class="line"></div><!-- /.line -->
                                    </div><!-- /.top-block -->
                                    <ul class="feature-lists text-left">
                                        <li><span style="color:#f00">*</span> {{__('rep-man-up')}} <span style="font-weight:bold;font-size:16px">7</span></li>
                                        <li><span style="color:#f00">*</span> {{__('rep-unlim')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-up-to-50')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-property')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-reports')}} </li>
                                        <li><span style="color:#f00">*</span> {{__('rep-auto-a')}}  <span style="padding:5px;color:#f00"> {{__('rep-extra')}} </span></li>
                                    </ul><!-- /.feature-lists text-left -->
                                    <div class="bottom-block bottom-blocks">
                                        <a href="learn-moreen.php"> {{__('rep-learn')}} </a>
                                        <a href="../stickypost_register/register-en.php?language=2" class="price-btn" style="cursor: pointer;"> {{__('rep-buy')}} </a>
                                        <h5 class="tag-line text-center"> {{__('rep-no-fees')}} <br> {{__('rep-cancel')}} </h5>
                             <p> {{__('rep-free-trial')}} </p>
                                    </div><!-- /.bottom-block -->
                                </div><!-- /.single-pricing-one -->
                                    </div> 
                                    <div class="col-sm-4 col-md-4 col-lg-2 p-1"  >
                                    <div class="single-pricing-one pro-pack">
                                    <div class="top-block" style="direction: ltr;">
                                        <h2> {{__('rep-special')}} </h2>
                                    <p class="price m-0" style="direction: rtl;"><?php if ($location == 'Egypt' ){echo '1584 EGP';}elseif ($location == 'United Arab Emirates'){echo '370 Dirham';} else {echo '101$';} ?></P>

                                        <div class="line"></div><!-- /.line -->
                                    </div><!-- /.top-block -->
                                    <ul class="feature-lists text-left">
                                        <li><span style="color:#f00">*</span>{{__('rep-man-up')}}<span style="font-weight:bold;font-size:16px">14</span></li>
                                        <li><span style="color:#f00">*</span>{{__('rep-unlim')}}</li>
                                        <li><span style="color:#f00">*</span>{{__('rep-up-to-50')}} </li>
                                        <li><span style="color:#f00">*</span>{{__('rep-property')}}   </li>
                                        <li><span style="color:#f00">*</span>{{__('rep-reports')}}</li>
                                        <li><span style="color:#f00">*</span>{{__('rep-auto-a')}} <span style="padding:5px;color:#f00">{{__('rep-extra')}} </span></li>
                                        <li><span style="color:#f00">*</span>{{__('rep-adding-mult')}}  <span style="padding:5px;color:#f00">{{__('rep-extra')}} </span></li>
                                    </ul><!-- /.feature-lists text-left -->
                                    <div class="bottom-block">
                                        <a href="learn-moreen.php">{{__('rep-learn')}}</a>
                                        <a href="../stickypost_register/register-en.php?language=2" class="price-btn" style="cursor: pointer;">{{__('rep-buy')}}</a>
                                        <h5 class="tag-line text-center">{{__('rep-no-fees')}} <br> {{__('rep-cancel')}}</h5>
                                        <p>{{__('rep-free-trial')}}</p>
                                    </div><!-- /.bottom-block -->
                                </div><!-- /.single-pricing-one -->
                                    </div> 
                                </div>
                        </div><!-- /.row -->
                    </div><!-- /.tab-pane -->
                </div><!-- /.tab-content -->
               
            </div>
        </section><!-- /.pricing-style-one -->
         @include('sticky.layout.partials.common.compare')
        <div class="hide-mobile">
            @include('sticky.layout.partials.common.reviews')
        </div>
    </div><!-- /.page-wrapper -->


    @endsection
    
    @push('scripts')
    
    
    @endpush