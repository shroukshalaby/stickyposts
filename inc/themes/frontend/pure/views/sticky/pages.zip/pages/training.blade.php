@extends('sticky.layout.master')
@push('head')
<style>
    .site-header{
    background:linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);
}
    body{
        overflow-x: hidden;
    }
    .subscribe_form button{
        margin:0;
    }
.try{
    display: block;
    position: absolute;
    left: 50%;
    top: 0;
    width: 12px;
    height: 12px;
    margin:-41px 0 0 -35px;
    border-radius: 50%;
    z-index: 2;
}
@media (max-width:567px){
#chartdiv {
  width: 100%;
  height: 300px;
} 
.my-width{
    width:90%;
    margin:auto;
}
.my-width h3{ 
font-size: 1.5rem !important;
    color: #320b82;
    text-align: left !important;
}  
.cont-try{
display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
}
.try{
    display: inline;
    position: relative;
    left: 0;
    top: 0;
    width: 12px;
    height: 12px;
    margin: 0;
    border-radius: 50%;
    z-index: 0;
}
 .my-marg{
     margin-left:1.2rem;
 }
}
@media (min-width:567px){
#chartdiv {
  width: 100%;
  height: 500px;
} 
 .my-marg{
     margin-left:3rem;
 }   
}
option{
    color: #320b82;
}
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: linear-gradient(-145deg, #320b82 0%, #9c33c3 100%); 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #b30000; 
}
#myTab .nav-link
{
   padding:2px 20px; 
   background:linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);
   color:#fff;
}
#myTab  .active
{
   padding:2px 20px; 
   color:#320b82;
   background:#fff;
}
.nav-tabs{
    border:none;
}
.block-title{
    font-weight: 600;
    color:#320b82;
    text-transform: uppercase;
}
}
/*******************************/
.multiselect-container>li{
 width: max-content;
}
.multiselect-container>li {
    padding: 0;
    height: 30px!important;
}
#output {
  padding: 20px;
  background: #dadada;
}

form {
  margin-top: 20px;
}

.multiselect-selected-text{
    white-space: pre-wrap; 
}
.btn-group{
    width: 100%;
    border: 1px solid #ddd;
    margin: 0 0 15px;
    border-radius: 0.25rem;
}
.btn-group .multiselect {
    white-space: nowrap;
    padding: 0px 2px;
    min-height: 30px;
    overflow: hidden;
    margin:0;
}
.dropdown-menu.show{
    transform: translate3d(8px, 41px, 0px) !important;
    top: 6px !important;
    left: -8px !important;
    width: 100% !important;
}
.btn-group .dropdown-toggle::after{
        position: absolute;
    top: 12px;
    right: 15px;
}
.form-control{
    height:25px;
    line-height:1.4;
    font-size: 12px;
    padding:0px 10px ;
}
.multiselect-container>li>a>label {
    margin: 0;
    height: 100%;
    cursor: pointer;
    font-weight: 400;
    padding: 3px 0px 3px 10px;
}
.btn-group .multiselect {
    text-align: left;
    padding: 0 10px;
    font-size: 12px;
}
.ui-widget.ui-widget-content{
    z-index:85 !important;
}
.timeline > div > a .desc-holder{
    padding:0;
}
.timeline > div > a h4{
    margin-bottom:12px;
    font-size:14px;
}
.block-title {
    font-weight: bold;
    color: #320b82;
    text-transform: inherit;
}
.multiselect-container{
    height: 247px;
    overflow: auto;
}
@media (min-width: 992px){
    .training-step a:hover h4 {
        color: #9c33c3;
        -webkit-transform: translate(0, -14px);
        -ms-transform: translate(0, -14px);
        -o-transform: translate(0, -14px);
        transform: translate(0, -14px);
    }
    
}
    .training-step a{
        text-align: center;
    }
    .training-step{
        text-align: center;
        padding-bottom: 40px;
    }
    .training-step a h4 span{
        color: #320C7F;
        font-size: 17px;
    }
    .training-step a h4{
        font-size: 14px;
        margin-bottom: 12px;
        text-transform: uppercase;
        font-weight: 700;
        transition: 0.2s;
        color: #b59ecf;
    }
    body{
        font-family: Helvetica !Important;
    }

</style>
@endpush

@section('page-wrapper')




@endsection



@section('body')
	<div id="page">
       
        <div class="container pt-5 mt-5 text-center">
            
            <div class="row justify-content-center">
                <div class="col-12">
                    <h2 class="block-title text-center">{{__('training_we_care')}} </h2>
                </div>
                <div class="col-lg-6 col-md-8 col-12">
                    <h5 class="block-title text-center mb-2"> {{__('training_therefore')}}</h5>
                </div>
            </div>
            
            <div class='container mt-5'>
                <div id="chartdiv"></div>
            </div>
              
        </div>
        <form class="addTraining" method="post">
                     
            <div class='container my-5 px-md-0 px-3'>
	            <div class="row">
	                <div class="col-md-3 training-step">
	                    <a class="mb-4">
							<h4 style=""><span style="color:#320C7F">{{__('training_step')}} 1 </span><br>{{__('trainig_create')}}</h4>
							<div class="desc-holder">
							<div ><img style="width:72px;z-index:-10" src="{{get_theme_frontend_url('assets/sticky/images/m3.png')}}"></div>
							</div>
						</a>
						<input type="hidden" name="lang" value="en">
		                <input type="hidden" name="assigned_employee" value="<?= $_GET['assigned_employee'] ?>">
                        <input type="hidden" name="activity" value="<?= $_GET['activity'] ?>">
                        <input type="hidden" name="task" value="<?= $_GET['task'] ?>">
						<div class="custom-control custom-radio" style="display: inline;">
                          <input type="radio"  id="type2" onclick="show2();" name="type" value="Company" class="custom-control-input">
                          <label class="custom-control-label font-weight-bold" for="type2">{{__('training_company')}}</label>
                        </div>
						<div class="custom-control custom-radio" style="display: inline;">
                          <input type="radio"  id="type1" onclick="show1();" name="type" value="Individual" class="custom-control-input" required>
                          <label class="custom-control-label font-weight-bold" for="type1">{{__('training_ind')}} </label>
                        </div>
                        
                        <div class="col-12 mb-1">
                            <div class="form-group">
                                <input type="text" class="form-control" name="fname" id="firstName" placeholder= "{{__('training_fname')}} " aria-describedby="inputGroupPrepend2" required>
                            </div>
                        </div>
                        <div class="col-12 mb-1">
                            <div class="form-group">
                                <input type="text" class="form-control" name="lname" id="lastName" placeholder= "{{__('training_lname')}} " aria-describedby="inputGroupPrepend2" required>
                              </div>
                        </div>
                        <div class="col-12 mb-1">
                            <div class="form-group">
                                <input type="text" class="form-control" id="mail" name="email" placeholder= "{{__('training_mail')}} " aria-describedby="inputGroupPrepend2" required>
                            </div>
                        </div>
                        <div class="col-12 mb-1">
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder= "{{__('training_password')}} " aria-describedby="inputGroupPrepend2" required>
                            </div>
                        </div>
                        <div class="col-12 text-left" style="" id="showform2">
                       
                            <div class="form-group">
                                <input id="company_name" type="text" class="form-control" name="company" placeholder= "{{__('training_company_name')}} " aria-describedby="inputGroupPrepend2">
                            </div> 
                            <div class="form-group">
                                <select class="form-control" id="emp_num_" name="numOfEmps">
                                      <option value="">{{__('training_empolyee')}} </option>
                                      <option value="1-50">1 - 50</option>
                                      <option value="51-100">51 - 100</option>
                                      <option value="101-500">101 - 500</option>
                                      <option value="501-1000">501- 1000</option>
                                      <option value="1000-1000000">{{__('training_more_than')}}  1000</option>
                                  </select> 
                            </div>
                        </div>
                        <div class="col-12 mb-1">
                            <div class="form-group">
                                <input type="phone" name="phone" class="form-control" id="phone" placeholder= "{{__('training_phone_number')}} " aria-describedby="inputGroupPrepend2" required>
                            </div>
                        </div>
	                </div>
	                <div class="col-md-3 training-step">
						<a class="mb-4">
							<h4 style=""><span style="color:#320C7F">{{__('training_step')}}  2 </span><br>{{__('training_topic')}}   </h4>
							<div class="desc-holder">
							    <div ><img style="width:72px;z-index:-10" src="{{get_theme_frontend_url('assets/sticky/images/m1.png')}}"></div>
							</div>
						</a>
						<div class="col-12 mb-1 mt-4">
                          <select name="topic[]" id="non-select" class="multi w-100 m-0 p-0"  multiple searchable="Search here.." style="height:24px;">
                            
                              
                              <?php
                              
                              foreach($topics as $topic){
                                  $topic_name = $topic['name'];
                                  $topic_id = $topic['id'];
                                  echo "<option value='$topic_id'>$topic_name</option>";
                              }
                              
                              ?>
                              
                              <!--<option value="Sticky Posts system Training.">Sticky Posts system Training. </option>-->
                              <!--<option value="Digital Marketing Training.">Digital Marketing Training.</option>-->
                              <!--<option value="Social media Content training.">Social media Content training.</option>-->
                              <!--<option value="Influencers Marketing ."> Influencers Marketing .</option>-->
                              <!--<option value="Start-ups Management Training.">Start-ups Management Training.</option>-->
                              <!--<option value="E-Commerce Marketing Training.">E-Commerce Marketing Training.</option>-->
                              <!--<option value="Photoshop & final retouch Training.">Photoshop & final retouch Training.</option>-->
                              <!--<option value="Events Management & Planning  Training.">Events Management & Planning  Training.</option>-->
                
                            </select>
                        </div>
					</div>
					<div class="col-md-3 training-step mx-md-0 mx-3">
						<a class="">
							<h4 style=""><span style="color:#320C7F"> {{__('training_step')}}  3 </span><br>{{__('training_country')}}  </h4>
							<div class="desc-holder">								    
							    <div ><img style="width:72px" src="{{get_theme_frontend_url('assets/sticky/images/world.png')}}"></div>
							</div>
						</a>
						<select id="country" class="form-control mt-4" name="country" style='text-align-last: center;' required>
                           <option value="" selected >{{__('training_country')}} </option>
                           <option value="Afganistan">Afghanistan</option>
                           <option value="Albania">Albania</option>
                           <option value="Algeria">Algeria</option>
                           <option value="American Samoa">American Samoa</option>
                           <option value="Andorra">Andorra</option>
                           <option value="Angola">Angola</option>
                           <option value="Anguilla">Anguilla</option>
                           <option value="Antigua & Barbuda">Antigua & Barbuda</option>
                           <option value="Argentina">Argentina</option>
                           <option value="Armenia">Armenia</option>
                           <option value="Aruba">Aruba</option>
                           <option value="Australia">Australia</option>
                           <option value="Austria">Austria</option>
                           <option value="Azerbaijan">Azerbaijan</option>
                           <option value="Bahamas">Bahamas</option>
                           <option value="Bahrain">Bahrain</option>
                           <option value="Bangladesh">Bangladesh</option>
                           <option value="Barbados">Barbados</option>
                           <option value="Belarus">Belarus</option>
                           <option value="Belgium">Belgium</option>
                           <option value="Belize">Belize</option>
                           <option value="Benin">Benin</option>
                           <option value="Bermuda">Bermuda</option>
                           <option value="Bhutan">Bhutan</option>
                           <option value="Bolivia">Bolivia</option>
                           <option value="Bonaire">Bonaire</option>
                           <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
                           <option value="Botswana">Botswana</option>
                           <option value="Brazil">Brazil</option>
                           <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                           <option value="Brunei">Brunei</option>
                           <option value="Bulgaria">Bulgaria</option>
                           <option value="Burkina Faso">Burkina Faso</option>
                           <option value="Burundi">Burundi</option>
                           <option value="Cambodia">Cambodia</option>
                           <option value="Cameroon">Cameroon</option>
                           <option value="Canada">Canada</option>
                           <option value="Canary Islands">Canary Islands</option>
                           <option value="Cape Verde">Cape Verde</option>
                           <option value="Cayman Islands">Cayman Islands</option>
                           <option value="Central African Republic">Central African Republic</option>
                           <option value="Chad">Chad</option>
                           <option value="Channel Islands">Channel Islands</option>
                           <option value="Chile">Chile</option>
                           <option value="China">China</option>
                           <option value="Christmas Island">Christmas Island</option>
                           <option value="Cocos Island">Cocos Island</option>
                           <option value="Colombia">Colombia</option>
                           <option value="Comoros">Comoros</option>
                           <option value="Congo">Congo</option>
                           <option value="Cook Islands">Cook Islands</option>
                           <option value="Costa Rica">Costa Rica</option>
                           <option value="Cote DIvoire">Cote DIvoire</option>
                           <option value="Croatia">Croatia</option>
                           <option value="Cuba">Cuba</option>
                           <option value="Curaco">Curacao</option>
                           <option value="Cyprus">Cyprus</option>
                           <option value="Czech Republic">Czech Republic</option>
                           <option value="Denmark">Denmark</option>
                           <option value="Djibouti">Djibouti</option>
                           <option value="Dominica">Dominica</option>
                           <option value="Dominican Republic">Dominican Republic</option>
                           <option value="East Timor">East Timor</option>
                           <option value="Ecuador">Ecuador</option>
                           <option value="Egypt">Egypt</option>
                           <option value="El Salvador">El Salvador</option>
                           <option value="Equatorial Guinea">Equatorial Guinea</option>
                           <option value="Eritrea">Eritrea</option>
                           <option value="Estonia">Estonia</option>
                           <option value="Ethiopia">Ethiopia</option>
                           <option value="Falkland Islands">Falkland Islands</option>
                           <option value="Faroe Islands">Faroe Islands</option>
                           <option value="Fiji">Fiji</option>
                           <option value="Finland">Finland</option>
                           <option value="France">France</option>
                           <option value="French Guiana">French Guiana</option>
                           <option value="French Polynesia">French Polynesia</option>
                           <option value="French Southern Ter">French Southern Ter</option>
                           <option value="Gabon">Gabon</option>
                           <option value="Gambia">Gambia</option>
                           <option value="Georgia">Georgia</option>
                           <option value="Germany">Germany</option>
                           <option value="Ghana">Ghana</option>
                           <option value="Gibraltar">Gibraltar</option>
                           <option value="Great Britain">Great Britain</option>
                           <option value="Greece">Greece</option>
                           <option value="Greenland">Greenland</option>
                           <option value="Grenada">Grenada</option>
                           <option value="Guadeloupe">Guadeloupe</option>
                           <option value="Guam">Guam</option>
                           <option value="Guatemala">Guatemala</option>
                           <option value="Guinea">Guinea</option>
                           <option value="Guyana">Guyana</option>
                           <option value="Haiti">Haiti</option>
                           <option value="Hawaii">Hawaii</option>
                           <option value="Honduras">Honduras</option>
                           <option value="Hong Kong">Hong Kong</option>
                           <option value="Hungary">Hungary</option>
                           <option value="Iceland">Iceland</option>
                           <option value="Indonesia">Indonesia</option>
                           <option value="India">India</option>
                           <option value="Iran">Iran</option>
                           <option value="Iraq">Iraq</option>
                           <option value="Ireland">Ireland</option>
                           <option value="Isle of Man">Isle of Man</option>
                           <option value="Israel">Israel</option>
                           <option value="Italy">Italy</option>
                           <option value="Jamaica">Jamaica</option>
                           <option value="Japan">Japan</option>
                           <option value="Jordan">Jordan</option>
                           <option value="Kazakhstan">Kazakhstan</option>
                           <option value="Kenya">Kenya</option>
                           <option value="Kiribati">Kiribati</option>
                           <option value="Korea North">Korea North</option>
                           <option value="Korea Sout">Korea South</option>
                           <option value="Kuwait">Kuwait</option>
                           <option value="Kyrgyzstan">Kyrgyzstan</option>
                           <option value="Laos">Laos</option>
                           <option value="Latvia">Latvia</option>
                           <option value="Lebanon">Lebanon</option>
                           <option value="Lesotho">Lesotho</option>
                           <option value="Liberia">Liberia</option>
                           <option value="Libya">Libya</option>
                           <option value="Liechtenstein">Liechtenstein</option>
                           <option value="Lithuania">Lithuania</option>
                           <option value="Luxembourg">Luxembourg</option>
                           <option value="Macau">Macau</option>
                           <option value="Macedonia">Macedonia</option>
                           <option value="Madagascar">Madagascar</option>
                           <option value="Malaysia">Malaysia</option>
                           <option value="Malawi">Malawi</option>
                           <option value="Maldives">Maldives</option>
                           <option value="Mali">Mali</option>
                           <option value="Malta">Malta</option>
                           <option value="Marshall Islands">Marshall Islands</option>
                           <option value="Martinique">Martinique</option>
                           <option value="Mauritania">Mauritania</option>
                           <option value="Mauritius">Mauritius</option>
                           <option value="Mayotte">Mayotte</option>
                           <option value="Mexico">Mexico</option>
                           <option value="Midway Islands">Midway Islands</option>
                           <option value="Moldova">Moldova</option>
                           <option value="Monaco">Monaco</option>
                           <option value="Mongolia">Mongolia</option>
                           <option value="Montserrat">Montserrat</option>
                           <option value="Morocco">Morocco</option>
                           <option value="Mozambique">Mozambique</option>
                           <option value="Myanmar">Myanmar</option>
                           <option value="Nambia">Nambia</option>
                           <option value="Nauru">Nauru</option>
                           <option value="Nepal">Nepal</option>
                           <option value="Netherland Antilles">Netherland Antilles</option>
                           <option value="Netherlands">Netherlands (Holland, Europe)</option>
                           <option value="Nevis">Nevis</option>
                           <option value="New Caledonia">New Caledonia</option>
                           <option value="New Zealand">New Zealand</option>
                           <option value="Nicaragua">Nicaragua</option>
                           <option value="Niger">Niger</option>
                           <option value="Nigeria">Nigeria</option>
                           <option value="Niue">Niue</option>
                           <option value="Norfolk Island">Norfolk Island</option>
                           <option value="Norway">Norway</option>
                           <option value="Oman">Oman</option>
                           <option value="Pakistan">Pakistan</option>
                           <option value="Palau Island">Palau Island</option>
                           <option value="Palestine">Palestine</option>
                           <option value="Panama">Panama</option>
                           <option value="Papua New Guinea">Papua New Guinea</option>
                           <option value="Paraguay">Paraguay</option>
                           <option value="Peru">Peru</option>
                           <option value="Phillipines">Philippines</option>
                           <option value="Pitcairn Island">Pitcairn Island</option>
                           <option value="Poland">Poland</option>
                           <option value="Portugal">Portugal</option>
                           <option value="Puerto Rico">Puerto Rico</option>
                           <option value="Qatar">Qatar</option>
                           <option value="Republic of Montenegro">Republic of Montenegro</option>
                           <option value="Republic of Serbia">Republic of Serbia</option>
                           <option value="Reunion">Reunion</option>
                           <option value="Romania">Romania</option>
                           <option value="Russia">Russia</option>
                           <option value="Rwanda">Rwanda</option>
                           <option value="St Barthelemy">St Barthelemy</option>
                           <option value="St Eustatius">St Eustatius</option>
                           <option value="St Helena">St Helena</option>
                           <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                           <option value="St Lucia">St Lucia</option>
                           <option value="St Maarten">St Maarten</option>
                           <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
                           <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
                           <option value="Saipan">Saipan</option>
                           <option value="Samoa">Samoa</option>
                           <option value="Samoa American">Samoa American</option>
                           <option value="San Marino">San Marino</option>
                           <option value="Sao Tome & Principe">Sao Tome & Principe</option>
                           <option value="Saudi Arabia">Saudi Arabia</option>
                           <option value="Senegal">Senegal</option>
                           <option value="Seychelles">Seychelles</option>
                           <option value="Sierra Leone">Sierra Leone</option>
                           <option value="Singapore">Singapore</option>
                           <option value="Slovakia">Slovakia</option>
                           <option value="Slovenia">Slovenia</option>
                           <option value="Solomon Islands">Solomon Islands</option>
                           <option value="Somalia">Somalia</option>
                           <option value="South Africa">South Africa</option>
                           <option value="Spain">Spain</option>
                           <option value="Sri Lanka">Sri Lanka</option>
                           <option value="Sudan">Sudan</option>
                           <option value="Suriname">Suriname</option>
                           <option value="Swaziland">Swaziland</option>
                           <option value="Sweden">Sweden</option>
                           <option value="Switzerland">Switzerland</option>
                           <option value="Syria">Syria</option>
                           <option value="Tahiti">Tahiti</option>
                           <option value="Taiwan">Taiwan</option>
                           <option value="Tajikistan">Tajikistan</option>
                           <option value="Tanzania">Tanzania</option>
                           <option value="Thailand">Thailand</option>
                           <option value="Togo">Togo</option>
                           <option value="Tokelau">Tokelau</option>
                           <option value="Tonga">Tonga</option>
                           <option value="Trinidad & Tobago">Trinidad & Tobago</option>
                           <option value="Tunisia">Tunisia</option>
                           <option value="Turkey">Turkey</option>
                           <option value="Turkmenistan">Turkmenistan</option>
                           <option value="Turks & Caicos Is">Turks & Caicos Is</option>
                           <option value="Tuvalu">Tuvalu</option>
                           <option value="Uganda">Uganda</option>
                           <option value="United Kingdom">United Kingdom</option>
                           <option value="Ukraine">Ukraine</option>
                           <option value="United Arab Erimates">United Arab Emirates</option>
                           <option value="United States of America">United States of America</option>
                           <option value="Uraguay">Uruguay</option>
                           <option value="Uzbekistan">Uzbekistan</option>
                           <option value="Vanuatu">Vanuatu</option>
                           <option value="Vatican City State">Vatican City State</option>
                           <option value="Venezuela">Venezuela</option>
                           <option value="Vietnam">Vietnam</option>
                           <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                           <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                           <option value="Wake Island">Wake Island</option>
                           <option value="Wallis & Futana Is">Wallis & Futana Is</option>
                           <option value="Yemen">Yemen</option>
                           <option value="Zaire">Zaire</option>
                           <option value="Zambia">Zambia</option>
                           <option value="Zimbabwe">Zimbabwe</option>
                        </select>
						
					</div>
					<div class="col-md-3 training-step mx-md-0 mx-3">
						<a class="">
							<h4 style=""><span style="color:#320C7F">{{__('training_step')}}  4</span> <br>{{__('training_book')}}    </h4>
							<div class="desc-holder">
							    <div ><img style="width:72px;z-index:-10" src="{{get_theme_frontend_url('assets/sticky/images/m2.png')}}"></div>
							</div>
						</a>
						<input id="datepicker" type="text" class="form-control mt-4" name="date" placeholder="select date">
						<div class='text-center mt-3'>
                            <input class="submit sticky-btn" style="background: linear-gradient(215deg, #5e2298, #320b82);padding:5px 20px; border-radius:5px"  type="submit">
                        </div>
					</div> 
				</div>
            </div>
                               
        </form>

    </div>

@endsection
@push('scripts')
"{{get_theme_frontend_url('assets/sticky/js/map/core.js')}}"
<script src="{{get_theme_frontend_url('assets/sticky/js/map/core.js')}}"></script>
<script src="{{get_theme_frontend_url('assets/sticky/js/map/maps.js')}}"></script>
<script src="{{get_theme_frontend_url('assets/sticky/js/map/worldLow.js')}}"></script>
<script src="{{get_theme_frontend_url('assets/sticky/js/map/frozen.js')}}"></script>

<!-- Chart code -->
<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_frozen);
// Themes end

// Create map instance
var chart = am4core.create("chartdiv", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldLow;

// Set projection
chart.projection = new am4maps.projections.NaturalEarth1();

// Create map polygon series
var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());
polygonSeries.mapPolygons.template.strokeWidth = 0.5;


// Make map load polygon (like country names) data from GeoJSON
polygonSeries.useGeodata = true;

// Configure series
var polygonTemplate = polygonSeries.mapPolygons.template;
polygonTemplate.tooltipText = "{name}";
polygonTemplate.fill = chart.colors.getIndex(0);

// Create hover state and set alternative fill color
var hs = polygonTemplate.states.create("hover");
hs.properties.fill = chart.colors.getIndex(2);

// Create active state
var activeState = polygonTemplate.states.create("active");
activeState.properties.fill = chart.colors.getIndex(4);

var graticuleSeries = chart.series.push(new am4maps.GraticuleSeries());

// Create an event to toggle "active" state
polygonTemplate.events.on("hit", function(ev) {
  ev.target.isActive = !ev.target.isActive;
  console.log("--->", polygonSeries)
})



}); // end am4core.ready()
</script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.min.js'></script>
<script src="https://www.aiearning.com/assets/countrycode/js/intlTelInput.js"></script>
	<!-- page -->
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  
    $(".addTraining").submit(function(e){
        e.preventDefault(e);
            $('.loader').modal('show');
            $('.lds-ring').show();
            $('.modal-body').html('....');
        $.ajax({
            url:"addTraining.php",
            dataType:'text',
            type:"POST",
            data:$(this).serialize() + '&token=' + getToken(),
            success:function(response){
                $('.lds-ring').hide();
                $('.modal-body').html(response);
            }
        })
    }); 
  </script>
<script>
      $("#non-select").multiselect({
  nonSelectedText:'Choose your favorite Topics'
});
  </script>
<script>
 
$('.multi').multiselect();
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
// $('#country').change(function(){
//   if($(this).children("option:selected").val()!=""){
//       document.getElementById("showForm").style.display="block";
//   }
    
// })
$('#showform2').css('visibility', 'hidden');
$('#showform2').css('position', 'absolute');
function show1(){
  $('#company_name').removeAttr('required');
  $('#emp_num_').removeAttr('required');
  $('#showform2').css('visibility', 'hidden');
  $('#showform2').css('position', 'absolute');
}
function show2(){
  $('#company_name').attr('required', 'true');
  $('#emp_num_').attr('required', 'true');
  $('#showform2').css('visibility', 'visible');
  $('#showform2').css('position', 'relative');
}
function lang1() {
        location.assign("training.php" + lang_url_params)
    }
    function lang2() {
        location.assign("trainings-Fr.php" + lang_url_params)
    }
</script>
@endpush
