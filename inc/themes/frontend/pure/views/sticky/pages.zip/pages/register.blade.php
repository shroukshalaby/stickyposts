@extends('sticky.layout.master')
@section('title','Sticky posts - Register' )

@push('head')

    <link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/register-new.css')}}">
    <link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/register-english.css')}}">
    <link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/layout.css')}}">
    <link rel="stylesheet" href="{{get_theme_frontend_url('assets/sticky/css/oauth-page.css')}}">
    <style>
        .oauth-wrap .oauth-form .nav-tabs li > a {
            padding: 2px;
            border-radius: 5px 5px 0px 0px;
        }

        @media (min-width: 567px) {
            body {
                font-size: 16px;
                color: #777b92;
            }

            a:active,
            a:hover,
            a:focus,
            a:visited {
                text-decoration: none;
            }

            .page-wrapper {
                position: relative;
                margin: 0 auto;
                width: 100%;
                min-width: 300px;
                overflow: hidden;
            }

            @media (min-width: 1200px) {
                .container {
                    max-width: 1300px;
                }
            }
            hr.style-one {
                margin: 0;
                border-top: 1px solid #EAEAEA;
            }

            .block-title {
                margin-bottom: 15px;
            }

            .block-title h2 {
                margin: 0;
                color: #320b82;
                font-size: 46px;
                margin-top: 10px;
                font-weight: 400;
            }

            .preloader {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 9999;
                background-color: #fff;
                /*background-image: url(../images/preloader.gif);*/
                /*background-repeat: no-repeat;*/
                /*background-position: center center;*/
            }

            .scroll-to-top {
                display: inline-block;
                width: 45px;
                height: 45px;
                background: #320b82;
                border-radius: 4px;
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 99;
                text-align: center;
                transition: all .4s ease;
                display: none;
            }

            .scroll-to-top i {
                font-size: 18px;
                line-height: 45px;
                color: #fff;
            }

            .scroll-to-top:hover {
                background: #273167;
            }

            /*
            * 3.header styles
            */
            @media (min-width: 1200px) {
                .container {
                    max-width: 1200px;
                }
            }
            .header-navigation {
                background-color: transparent;
                margin-bottom: 0;
                border: none;
                border-radius: 0;
                padding: 7px 0;
                position: relative;
                background-color: transparent;
            }

            .header-navigation .container {
                background: transparent;
                position: relative;
                display: block;
            }

            .header-navigation .container .logo-box {
                float: left;
                position: absolute;
                top: 50%;
                left: 0px;
                width: 20.5%;
                -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
            }

            .header-navigation .container .navbar-brand {
                height: auto;
                margin: 0;
            }

            .header-navigation .container .menu-toggler {
                display: none;
            }

            .header-navigation .container .right-side-box {
                position: absolute;
                top: 50%;
                -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
                right: 15px;
            }

            .header-navigation .main-navigation {
                float: right;
                text-align: right;
            }

            @media (min-width: 1200px) {
                .header-navigation .main-navigation {
                    display: block !important;
                }
            }

            .header-navigation ul.navigation-box {
                margin: 0;
                padding: 0;
                list-style: none;
                display: flex;
                align-items: center;
            }

            .header-navigation ul.navigation-box li a .sub-nav-toggler {
                display: none;
            }

            .header-navigation ul.navigation-box > li {
                position: relative;
                padding: 0px 0;
                display: inline-block;
                vertical-align: middle;
                /* Second Level Menu */
                /* Thrid Level Menu */
            }

            .header-navigation ul.navigation-box > li:first-child {
                padding-left: 0;
            }

            .header-navigation ul.navigation-box > li:last-child {
                padding-right: 0;
            }

            .header-navigation ul.navigation-box > li > a {
                font-weight: 500;
                font-size: 16px;
                color: #777B92;
                padding: 0;
                transition: all .4s ease;
                position: relative;
            }

            .header-navigation ul.navigation-box > li.current > a:before, .header-navigation ul.navigation-box > li:hover > a:before {
                -webkit-transform: scale(1, 1);
                transform: scale(1, 1);
                -webkit-transform-origin: left center;
                transform-origin: left center;
            }

            .header-navigation ul.navigation-box > li > .sub-menu {
                position: absolute;
                top: 100%;
                left: 0;
                z-index: 1000;
                float: left;
                min-width: 220px;
                padding: 0px 0px;
                text-align: left;
                list-style: none;
                background-color: #273167;
                background-clip: padding-box;
                opacity: 0;
                border-radius: 0px;
                visibility: hidden;
                transition: opacity .4s ease, visibility .4s ease;
                box-shadow: 0px 10px 18px rgba(0, 0, 0, 0.1);
            }

            @media (min-width: 1200px) {
                .header-navigation ul.navigation-box > li > .sub-menu {
                    display: block !important;
                }
            }
            .header-navigation ul.navigation-box > li > .sub-menu.right-align {
                left: auto;
                right: 0;
            }

            .header-navigation ul.navigation-box > li > .sub-menu.center-align {
                left: 50%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }

            .header-navigation ul.navigation-box > li > .sub-menu > li {
                display: block;
                position: relative;
                transition: all .4s ease;
            }

            .header-navigation ul.navigation-box > li > .sub-menu > li + li {
                border-top: 1px solid rgba(255, 255, 255, 0.1);
            }

            .header-navigation ul.navigation-box > li > .sub-menu > li > a {
                font-size: 15px;
                color: #fff;
                font-weight: 500;
                padding: 12px 30px;
                display: block;
                line-height: 26px;
                white-space: nowrap;
                position: relative;
                transition: all .4s ease;
            }

            .header-navigation ul.navigation-box > li > .sub-menu > li:hover > a {
                color: #273167;
                background: #fff;
            }

            .header-navigation ul.navigation-box > li:hover:before {
                -webkit-transform: scale(1, 1);
                transform: scale(1, 1);
                -webkit-transform-origin: left bottom;
                transform-origin: left bottom;
            }

            .header-navigation ul.navigation-box > li:hover > .sub-menu {
                opacity: 1;
                visibility: visible;
            }

            .header-navigation ul.navigation-box > li > ul > li {
                /* no more nested showen */
            }

            .header-navigation ul.navigation-box > li > ul > li > .sub-menu {
                position: absolute;
                top: 0%;
                left: 100%;
                z-index: 1000;
                float: left;
                min-width: 220px;
                padding: 0px 0px;
                text-align: left;
                list-style: none;
                background-color: #273167;
                background-clip: padding-box;
                opacity: 0;
                border-radius: 0px;
                visibility: hidden;
                transition: opacity .4s ease, visibility .4s ease;
                box-shadow: 0px 10px 18px rgba(0, 0, 0, 0.1);
            }

            @media (min-width: 1200px) {
                .header-navigation ul.navigation-box > li > ul > li > .sub-menu {
                    display: block !important;
                }
            }
            .header-navigation ul.navigation-box > li > ul > li > .sub-menu.right-align {
                left: auto;
                right: 100%;
            }

            .header-navigation ul.navigation-box > li > ul > li > .sub-menu.center-align {
                left: 50%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }

            .header-navigation ul.navigation-box > li > ul > li > .sub-menu > li {
                display: block;
                position: relative;
                transition: all .4s ease;
            }

            .header-navigation ul.navigation-box > li > ul > li > .sub-menu > li + li {
                border-top: 1px solid rgba(255, 255, 255, 0.1);
            }

            .header-navigation ul.navigation-box > li > ul > li > .sub-menu > li > a {
                font-size: 15px;
                color: #fff;
                font-weight: 500;
                padding: 12px 30px;
                display: block;
                line-height: 26px;
                white-space: nowrap;
                position: relative;
                transition: all .4s ease;
            }

            .header-navigation ul.navigation-box > li > ul > li > .sub-menu > li:hover > a {
                color: #273167;
                background: #fff;
            }

            .header-navigation ul.navigation-box > li > ul > li:hover > .sub-menu {
                opacity: 1;
                visibility: visible;
            }

            .header-navigation ul.navigation-box > li > ul > li ul {
                display: none;
            }

            .header-navigation.stricky-fixed {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                z-index: 991;
                background: #273167;
                border-bottom: 0;
            }

            .site-header.header-one {
                background-color: transparent;
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                z-index: 99;
            }

            .site-header.header-one .header-navigation {
                background: transparent;
            }

            .site-header.header-one .header-navigation.stricky-fixed {
                background-color: #fff;
                box-shadow: 0px 5px 30px 0px rgba(233, 79, 202, 0.05);
            }

            .site-header.header-one .header-navigation ul.navigation-box > li.current > a,
            .site-header.header-one .header-navigation ul.navigation-box > li:hover > a {
                color: #E94FCA;
            }

            .site-header.header-one .header-navigation ul.navigation-box > li {
                margin: 0 12px;
            }

            .site-header.header-one .header-navigation .header-btn {
                vertical-align: middle;
                border-radius: 5px;
                background-color: white !important;
                color: #320B82 !important;
                font-size: 16px;
                font-weight: 500;
                padding: 2px 6px 3px !important;
                line-height: 1.3;
            }

            .site-header.header-one .header-navigation.stricky-fixed ul.navigation-box > li {
                padding: 3px 0;
            }

            .site-header.home-page-two .header-navigation.stricky-fixed {
                background-image: linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);
                box-shadow: 0px 10px 60px 0px rgba(0, 0, 0, 0.15);
            }

            .site-header.home-page-two .header-navigation ul.navigation-box > li > a {
                color: #fff;
            }

            .site-header.home-page-two .header-navigation ul.navigation-box > li.current > a,
            .site-header.home-page-two .header-navigation ul.navigation-box > li:hover > a {
                color: #fff;
            }

            .site-header.home-page-two .header-navigation .right-side-box .header-btn:hover {
                color: #fff;
                background-color: #E94FCA;
                border-color: #E94FCA;
            }

        }

        .nav-tabs .nav-link {
            border: none;
        }

        .oauth-wrap .oauth-form .nav-tabs .active {
            color: #fff;
        }

        #myTab1 .active {
            background: linear-gradient(90deg, #33a3fb, #7c07bd)
        }

        #myTab2 .active {
            background: linear-gradient(90deg, #FF9800, #f8f900)
        }

        #myTab3 .active {
            background: linear-gradient(90deg, #369e36, #c2fc03)
        }

        #myTab4 .active {
            background: linear-gradient(90deg, #e09d0d, #d707f3)
        }

        @media (min-width: 1200px) {
            .container {
                min-width: 1170px;
                max-width: 1200px;
            }
        }

        label {
            direction: ltr;
        }

        .pure-checkbox {
            font-size: 12px;
        }

        .lds-ring {
            display: inline-block;
            position: relative;
            width: 80px;
            height: 80px;
        }

        .lds-ring img {
            box-sizing: border-box;
            display: block;
            position: absolute;
            width: 64px;
            height: 64px;
            margin: 8px;
            border-radius: 50%;
            animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
            border-color: #fff transparent transparent transparent;
        }

        @keyframes lds-ring {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        .model-tabs {
            background-color: #f3eaf7;
            padding: 2px 11px;
            border-radius: 3px;
        }
    </style>
@endpush

@section('body')

    <div class="text-center">
        <h5 class="text-light text-center main-title" style="line-height: 2;">
            The easiest and most economical social media scheduling and
            <br>
            management system all over the world using AI technology. Now, in its Arabic Edition</h5>
    </div>

    <div class="row mx-0 mt-5 justify-content-center" style="align-items: center;">
        <div class="col-lg-5 col-md-10">
            <div class="flex-accordion box_shadow ">
                <ul>
                    <li class="at-accordion__panel">
                        <div class="panel-inner">
                            <!-- <a href="case.html"> -->
                            <div class="title my-border">
                                <!-- <div class="title__inner"> -->
                                <h6 class="title__text">Stickyposts</h6>
                                <!-- </div> -->

                            </div>

                            <div class="oauth-wrap">
                                <div class="oauth-form p-0 m-0" style=" ">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">

                                        <li class="nav-item"><a class="nav-link" href="https://stickyposts.net/auth/login?language=0"> login</a></li>
                                        <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Register</a></li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                                            <div class="tab-content pb15">
                                                <form class="form">
                                                    <div class="tab-pane active text-left">
                                                        <div class="form-group m-0">
                                                            <label for="fullname"><span style="color:red">*</span>First name</label>
                                                            <input type="text" class="form-control" id="fullname" name="fullname" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="lastname"><span style="color:red">*</span>Last name</label>
                                                            <input type="text" class="form-control" id="lastname" name="lastname" required="">
                                                        </div>
                                                        <input type="hidden" name="contract_id" id="contract-id" value="">
                                                        <input type="hidden" name="goto" value="sticky">
                                                        <input type="hidden" name="register_by" value="">

                                                        <input type="hidden" name="activity_source" value="0">
                                                        <input type="hidden" name="task_source" value="0">




                                                        <input type="hidden" name="leads" id="leads" value="">
                                                        <input type="hidden" name="prom_code" id="prom_code" value="">
                                                        <input type="hidden" name="lang" id="lang" value="1">
                                                        <input type="hidden" name="transaction_id" id="transaction-id" value="">
                                                        <div class="form-group m-0">
                                                            <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                            <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" name="email" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                            <input type="password" class="form-control password" name="password">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for=""><span style="color:red">*</span> Country</label>
                                                            <select class="form-control" name="country" required="">
                                                              @include('sticky.layout.partials.helpers.countries')
                                                            </select>
                                                        </div>
                                                        <p style="font-size:10px;color:#f00;margin: 0;"><span style="color:red;font-size: 15px;">*</span> All fields are required to fill in </p>
                                                        <label for="">Do you want to</label>
                                                        <div class="form-group mb-0">
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input" id="yesCheck" name="yesno" value="resources">
                                                                <label class="custom-control-label" for="yesCheck">Get resources &amp; receive newsletters  </label>
                                                            </div>
                                                        </div>
                                                        <div class="checkbox">
                                                            <div class="pure-checkbox grey mb-1">
                                                                <span class="checkbox-text-left ml-3"> I agree to the  <a href="../sticky/terms.php" style="text-decoration:underline;color: #673ab7;font-weight: bold;">terms and conditions</a></span>
                                                                <input type="checkbox" id="md_checkbox_schedule" name="terms" class="filled-in chk-col-red enable_instagram_schedule" value="on" required="">
                                                                <label class="p0 m0" for="md_checkbox_schedule">&nbsp;</label>


                                                            </div>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary btn-block" style="background: linear-gradient(90deg,#320b82, #9c33c3 );margin: auto;border: none;" id="submit"> Register Now</button>

                                                    </div>
                                                    <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                            <form>
                                                <div class="form-group  my-3">
                                                    <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                    <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" name="email" required="">
                                                </div>
                                                <div class="form-group my-3">
                                                    <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                    <input type="password" class="form-control password" name="password">

                                                </div>
                                                <button type="submit" class="btn btn-primary btn-block my-3" style="background: linear-gradient(90deg,#320b82, #9c33c3 );margin: auto;border: none;" id="submit"> الlogin </button>
                                                <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                        </div></div>

                                </div>
                            </div>
                            <!-- </a> -->
                        </div>
                    </li>
                    <li class="at-accordion__panel">
                        <div class="panel-inner">
                            <!-- <a href="case.html"> -->
                            <div class="title AUTOACTIVITY my-border">
                                <!-- <div class="title__inner"> -->
                                <h6 class="title__text">auto Activity</h6>
                                <!-- </div> -->

                            </div>

                            <div class="oauth-wrap">
                                <div class="oauth-form p-0 m-0" style=" ">
                                    <ul class="nav nav-tabs" id="myTab4" role="tablist">

                                        <li class="nav-item"><a class="nav-link" href="https://stickyposts.net/auth/login?language=0"> login</a></li>
                                        <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Register</a></li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                                            <div class="tab-content pb15">
                                                <form class="form">
                                                    <div class="tab-pane active text-left">
                                                        <div class="form-group m-0">
                                                            <label for="fullname"><span style="color:red">*</span>First name</label>
                                                            <input type="text" class="form-control" id="fullname" name="fullname" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="lastname"><span style="color:red">*</span>Last name</label>
                                                            <input type="text" class="form-control" id="lastname" name="lastname" required="">
                                                        </div>
                                                        <input type="hidden" name="contract_id" id="contract-id" value="">
                                                        <input type="hidden" name="goto" value="autoactivity">
                                                        <input type="hidden" name="register_by" value="">

                                                        <input type="hidden" name="activity_source" value="0">
                                                        <input type="hidden" name="task_source" value="0">




                                                        <input type="hidden" name="leads" id="leads" value="">
                                                        <input type="hidden" name="prom_code" id="prom_code" value="">
                                                        <input type="hidden" name="lang" id="lang" value="1">
                                                        <input type="hidden" name="transaction_id" id="transaction-id" value="">
                                                        <div class="form-group m-0">
                                                            <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                            <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" name="email" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                            <input type="password" class="form-control password" name="password">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for=""><span style="color:red">*</span> Country</label>
                                                            <select class="form-control" name="country" required="">
                                                                @include('sticky.layout.partials.helpers.countries')
                                                            </select>
                                                        </div>
                                                        <p style="font-size:10px;color:#f00;margin: 0;"><span style="color:red;font-size: 15px;">*</span> All fields are required to fill in </p>
                                                        <label for="">Do you want to</label>
                                                        <div class="form-group mb-0">
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input" id="yesCheck11" name="yesno" value="resources">
                                                                <label class="custom-control-label" for="yesCheck11">Get resources &amp; receive newsletters  </label>
                                                            </div>
                                                        </div>
                                                        <div class="checkbox">
                                                            <div class="pure-checkbox grey mb-1">
                                                                <span class="checkbox-text-left ml-3"> I agree to the  <a href="https://stickyposts.net/p/terms_and_policies" style="text-decoration:underline;color: #673ab7;font-weight: bold;">terms and conditions</a></span>
                                                                <input type="checkbox" id="md_checkbox_schedule00" name="terms" class="filled-in chk-col-red enable_instagram_schedule" value="on" required="">
                                                                <label class="p0 m0" for="md_checkbox_schedule00">&nbsp;</label>


                                                            </div>
                                                        </div>

                                                        <button type="submit" class="btn btn-primary btn-block" style="background: linear-gradient(90deg,#e09d0d, #d707f3);margin: auto;border: none;" id="submit"> Register Now</button>

                                                    </div>
                                                    <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                            <form>
                                                <div class="form-group  my-3">
                                                    <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                    <input type="email" class="form-control" value="" name="email" required="">
                                                </div>
                                                <div class="form-group my-3">
                                                    <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                    <input type="password" class="form-control password" name="password">

                                                </div>
                                                <button type="submit" class="btn btn-primary btn-block my-3" style="background: linear-gradient(90deg,#320b82, #9c33c3 );margin: auto;border: none;" id="submit"> الlogin </button>
                                                <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                        </div></div>

                                </div>
                            </div>
                            <!-- </a> -->
                        </div>
                    </li>
                    <li class="at-accordion__panel">
                        <div class="panel-inner">
                            <!-- <a href="case.html"> -->
                            <div class="title ANALYZE my-border">
                                <!-- <div class="title__inner"> -->
                                <h3 class="title__text">Competitors &amp; Influencers </h3>
                                <!-- </div> -->
                            </div>

                            <div class="oauth-wrap">
                                <div class="oauth-form p-0 m-0" style=" ">
                                    <ul class="nav nav-tabs" id="myTab1" role="tablist">

                                        <li class="nav-item"><a class="nav-link" href="https://stickyposts.net/phpanalyzer/product3/login"> login</a></li>
                                        <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home1" role="tab" aria-controls="home" aria-selected="true">Register</a></li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home1" role="tabpanel" aria-labelledby="home-tab">

                                            <div class="tab-content pb15">
                                                <form class="form" data-zone="analyzer">
                                                    <input type="hidden" name="register_source" value="analyzer">
                                                    <div class="tab-pane active text-left">
                                                        <div class="form-group m-0">
                                                            <label for="fullname"><span style="color:red">*</span>Full name</label>
                                                            <input type="text" class="form-control" id="fullname" name="fullname" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="lastname"><span style="color:red">*</span>Last name</label>
                                                            <input type="text" class="form-control" id="lastname" name="lastname" required="">
                                                        </div>
                                                        <input type="hidden" name="contract_id" id="contract-id" value="">
                                                        <input type="hidden" name="goto" value="analyzer">
                                                        <input type="hidden" name="register_by" value="">

                                                        <input type="hidden" name="activity_source" value="0">
                                                        <input type="hidden" name="task_source" value="0">




                                                        <input type="hidden" name="leads" id="leads" value="">
                                                        <input type="hidden" name="lang" id="lang" value="1">
                                                        <input type="hidden" name="transaction_id" id="transaction-id" value="">
                                                        <div class="form-group m-0">
                                                            <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                            <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" name="email" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                            <input type="password" class="form-control password" name="password">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for=""><span style="color:red">*</span> Country</label>
                                                            <select class="form-control" name="country" required="">
                                                                @include('sticky.layout.partials.helpers.countries')
                                                            </select>
                                                        </div>
                                                        <p style="font-size:10px;color:#f00;margin: 0;"><span style="color:red;font-size: 15px;">*</span> All fields are required to fill in </p>
                                                        <label for="">Do you want to</label>
                                                        <div class="form-group mb-0">
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input" id="yesCheck1" name="yesno" value="resources" required="">
                                                                <label class="custom-control-label" for="yesCheck1">Get resources &amp; receive newsletters  </label>
                                                            </div>
                                                        </div>
                                                        <div class="checkbox">
                                                            <div class="pure-checkbox grey mb-1">
                                                                <span class="checkbox-text-left ml-3"> I agree to the  <a href="../sticky/terms.php" style="text-decoration:underline;color: #673ab7;font-weight: bold;">terms and conditions</a></span>
                                                                <input type="checkbox" id="md_checkbox_schedule1" name="terms" class="filled-in chk-col-red enable_instagram_schedule" value="on" required="">
                                                                <label class="p0 m0" for="md_checkbox_schedule1">&nbsp;</label>

                                                            </div>
                                                        </div>

                                                        <button type="submit" class="btn btn-primary btn-block" style="background:linear-gradient(90deg, #33a3fb, #7c07bd);margin: auto;border: none;" id="submit"> Resiter Now</button>

                                                    </div>
                                                    <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="profile1" role="tabpanel" aria-labelledby="profile-tab">
                                            <form>
                                                <div class="form-group  my-3">
                                                    <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                    <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" name="email" required="">
                                                </div>
                                                <div class="form-group  my-3">
                                                    <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                    <input type="password" class="form-control password" name="password">

                                                </div>
                                                <button type="submit" class="btn btn-primary btn-block my-3" style="background: linear-gradient(90deg,#33a3fb, #7c07bd );margin: auto;border: none;" id="submit"> الlogin </button>
                                                <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- </a> -->
                        </div>
                    </li>
                    <li class="at-accordion__panel">
                        <div class="panel-inner">
                            <!-- <a href="case.html"> -->
                            <div class="title FAMILY my-border">
                                <!-- <div class="title__inner"> -->
                                <h3 class="title__text">Family Service </h3>
                            </div>
                            <!-- </div> -->
                            <div class="oauth-wrap">
                                <div class="oauth-form p-0 m-0" style=" ">
                                    <ul class="nav nav-tabs" id="myTab2" role="tablist">

                                        <li class="nav-item"><a class="nav-link" href="https://stickyposts.net/auth/login?language=0"> login</a></li>
                                        <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home2" role="tab" aria-controls="home" aria-selected="true">Register</a></li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home2" role="tabpanel" aria-labelledby="home-tab">

                                            <div class="tab-content pb15">
                                                <form class="form">
                                                    <div class="tab-pane active text-left">
                                                        <div class="form-group m-0">
                                                            <label for="fullname"><span style="color:red">*</span>First name</label>
                                                            <input type="text" class="form-control" id="fullname" name="fullname" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="lastname"><span style="color:red">*</span>Last name</label>
                                                            <input type="text" class="form-control" id="lastname" name="lastname" required="">
                                                        </div>
                                                        <input type="hidden" name="contract_id" id="contract-id" value="">
                                                        <input type="hidden" name="goto" value="family">
                                                        <input type="hidden" name="register_by" value="">

                                                        <input type="hidden" name="activity_source" value="0">
                                                        <input type="hidden" name="task_source" value="0">




                                                        <input type="hidden" name="leads" id="leads" value="">
                                                        <input type="hidden" name="lang" id="lang" value="1">
                                                        <input type="hidden" name="transaction_id" id="transaction-id" value="">
                                                        <div class="form-group m-0">
                                                            <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                            <input type="email" class="form-control" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required="">
                                                        </div>
                                                        <div class="form-group ">
                                                            <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                            <input type="password" class="form-control password" name="password">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for=""><span style="color:red">*</span> Country</label>
                                                            <select class="form-control" name="country" required="">
                                                                @include('sticky.layout.partials.helpers.countries')
                                                            </select>
                                                        </div>
                                                        <p style="font-size:10px;color:#f00;margin: 0;"><span style="color:red;font-size: 15px;">*</span> All fields are required to fill in </p>
                                                        <label for="">Do you want to</label>
                                                        <div class="form-group mb-0">
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" class="custom-control-input" id="yesCheck2" name="yesno" value="resources" required="">
                                                                <label class="custom-control-label" for="yesCheck2">Get resources &amp; receive newsletters  </label>
                                                            </div>
                                                        </div>
                                                        <div class="checkbox">
                                                            <div class="pure-checkbox grey mb-1">
                                                                <span class="checkbox-text-left ml-3"> I agree to the  <a href="../sticky/terms.php" style="text-decoration:underline;color: #673ab7;font-weight: bold;">terms and conditions</a></span>
                                                                <input type="checkbox" id="md_checkbox_schedule2" name="terms" class="filled-in chk-col-red enable_instagram_schedule" value="on" required="">
                                                                <label class="p0 m0" for="md_checkbox_schedule2">&nbsp;</label>

                                                            </div>
                                                        </div>
                                                        <button type="submit" class="btn btn-block" style="color:#fff;background: linear-gradient(90deg, #FF9800 , #f8f900 );margin: auto;border: none;" id="submit"> Resiter Now</button>

                                                    </div>
                                                    <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="profile2" role="tabpanel" aria-labelledby="profile-tab">
                                            <form>
                                                <div class="form-group  my-3">
                                                    <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                    <input type="email" class="form-control" value="" name="email" required="">
                                                </div>
                                                <div class="form-group  my-3">
                                                    <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                    <input type="password" class="form-control password" name="password">

                                                </div>
                                                <button type="submit" class="btn btn-primary btn-block my-3" style="background: linear-gradient(90deg,#FF9800 , #f8f900 );margin: auto;border: none;" id="submit"> الlogin </button>
                                                <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="at-accordion__panel is-open">
                        <div class="panel-inner">
                            <!-- <a href="case.html"> -->
                            <div class="title ACTIVATION my-border">
                                <!-- <div class="title__inner"> -->
                                <h3 class="title__text">Activation</h3>
                            </div>
                            <!-- </div> -->
                            <div class="oauth-wrap">
                                <div class="oauth-form p-0 m-0" style=" ">
                                    <ul class="nav nav-tabs" id="myTab3" role="tablist">

                                        <li class="nav-item"><a class="nav-link" href="https://stickyposts.net/auth/login?language=0"> login</a></li>
                                        <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home3" role="tab" aria-controls="home" aria-selected="true">Register</a></li>
                                    </ul>

                                    <div class="tab-content pb-3" id="myTabContent" style="">
                                        <div class="tab-pane fade show active" id="home3" role="tabpanel" aria-labelledby="home-tab">

                                            <div class="tab-content pb15">
                                                <form id="active_code_form">
                                                    <div class="tab-pane active text-left">
                                                        <div class="form-group m-0">
                                                            <label for="fullname"><span style="color:red">*</span>First name</label>
                                                            <input type="text" class="form-control" id="fullname" name="fullname" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="lastname"><span style="color:red">*</span>Last name</label>
                                                            <input type="text" class="form-control" id="lastname" name="lastname" required="">
                                                        </div>
                                                        <input type="hidden" name="contract_id" id="contract-id" value="">
                                                        <input type="hidden" name="register_by" value="">

                                                        <input type="hidden" name="activity_source" value="0">
                                                        <input type="hidden" name="task_source" value="0">




                                                        <input type="hidden" name="goto" value="active">
                                                        <input type="hidden" name="leads" id="leads" value="">
                                                        <input type="hidden" name="lang" id="lang" value="1">
                                                        <input type="hidden" name="transaction_id" id="transaction-id" value="">
                                                        <div class="form-group m-0">
                                                            <label for="email"> <span style="color:red;font-size: 15px;">*</span>Phone</label>
                                                            <input type="number" class="form-control" name="phone" minlength="10" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                            <input type="email" class="form-control" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required="">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                            <input type="password" class="form-control password" name="password">
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <label for=""><span style="color:red">*</span> Country</label>
                                                            <select class="form-control" name="country" required="">
                                                                @include('sticky.layout.partials.helpers.countries')
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="fullname"><span style="color:red">*</span>Enter Your active code</label>
                                                            <input type="text" class="form-control" id="active_code" name="active_code" required="">
                                                        </div>
                                                        <!--    <p style="font-size:10px;color:#f00;margin: 0;"><span style="color:red;font-size: 15px;">*</span> All fields are required to fill in </p>-->
                                                        <!--<label for="">Do you want to</label>-->
                                                        <!--<div class="form-group mb-0">-->
                                                        <!--    <div class="custom-control custom-radio">-->
                                                        <!--        <input type="radio" class="custom-control-input" id='yesCheck3' name="yesno" value="resources" required>-->
                                                        <!--        <label class="custom-control-label" for="yesCheck3">Get resources & receive newsletters  </label>-->
                                                        <!--    </div>-->
                                                        <!--</div>-->
                                                        <!--<div class="checkbox">-->
                                                        <!--    <div class="pure-checkbox grey mb-1">-->
                                                        <!--        <input type="checkbox" id="md_checkbox_schedule3" name="terms" class="filled-in chk-col-red enable_instagram_schedule" value="on" required>-->
                                                        <!--        <label class="p0 m0" for="md_checkbox_schedule3">&nbsp;</label>-->
                                                        <!--        <span class="checkbox-text-left ml-3"> I agree to the  <a href="https://stickyposts.net/p/terms_and_policies" style="text-decoration:underline;color: #673ab7;font-weight: bold;">terms and conditions</a></span>-->
                                                        <!--    </div>-->
                                                        <!--</div>-->
                                                        <button type="submit" class="btn btn-block" style="color:#fff;background: linear-gradient(90deg, #369e36 , #c2fc03 );margin: auto;border: none;" id="submit"> Resiter Now</button>

                                                    </div>
                                                    <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="profile3" role="tabpanel" aria-labelledby="profile-tab">
                                            <form>
                                                <div class="form-group  my-3">
                                                    <label for="email"> <span style="color:red;font-size: 15px;">*</span> E-mail address</label>
                                                    <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" name="email" required="">
                                                </div>
                                                <div class="form-group  my-3">
                                                    <label for="pwd"><span style="color:red;font-size: 15px;">*</span>Password</label>
                                                    <input type="password" class="form-control password" name="password">

                                                </div>
                                                <button type="submit" class="btn btn-primary btn-block my-3" name="submit" style="background: linear-gradient(90deg,#FF9800 , #f8f900 );margin: auto;border: none;" id="submit"> الlogin </button>
                                                <input type="hidden" name="assigned_employee" value="0"><input type="hidden" name="activity" value="0"><input type="hidden" name="task" value="0"><input type="hidden" name="platform" value=""><input type="hidden" name="landing_page" value=""><input type="hidden" name="landing_category" value=""><input type="hidden" name="source" value=""><input type="hidden" name="assigned_b2b_id" value="0"><input type="hidden" name="assigned_b2b_source" value=""><input type="hidden" name="invited_by" value="0"></form>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-lg-6 d-none d-lg-block text-left">
            <div class="card-container box_shadow" style="padding: 12px;" id="content" dir="ltr"><div class="card-header text-center text-dark p-0" style="background:linear-gradient(90deg,#320b82,#9c33c3);height:36px;color:#fff"><h3 style="margin: 0;color:#fff">Sticky Posts</h3></div><article class="stack__card stack__card__right"><figure class="span__40"> <img class="lazyload" style="padding: 20px 10px;" src="../../portal.png" alt="Descriptive Text"></figure><div class="stack__card__content" dir="ltr"><h2 class="stack__card__title text-center">Schedule, Publish and Rate</h2><p>Register with Sticky Posts’ automated scheduling service to plan and publish on all your social media platforms at once from any place. </p></div></article></div>
        </div>

        <div class="col-12" id="card1" dir="ltr">
            <h2 class="main-title" style="margin:15px 0;text-align:center">Download e-book for FREE</h2>
            <div class="col-md-6 mx-auto video-card">
                <div class="row my-row">

                    <!--1-->
                    <div class="col-md-6 my-auto text-center stickycov" id="video-card" style="display: none;">
                        <h3>Download e-book for FREE</h3>
                        <p>Smart marketing: how to sell more and spend less?</p>
                        <button class="btn dowenload-btn downNow2" value="36" style="background:linear-gradient(90deg, #320b82 , #9c33c3  )" type="button" title="Send">Download Now</button>
                    </div>
                    <div class="col-md-6 my-auto stickycov" style="margin-top: 4px; display: none;" id="video-img">
                        <img src="https://crmmrkt.com/crmmarket/uploads/image/22993_best plan for the blog.jpg" class="img-fluid">
                    </div>
                    <!--2-->
                    <div class="col-md-6 my-auto text-center" id="video-card2" style="display: none;">
                        <h3>Download e-book for FREE</h3>
                        <p>10 Tips For Increasing Your Social Media Engagement Rate Guide 2020</p>
                        <button class="btn dowenload-btn downNow2" value="40" style="background:linear-gradient(90deg, #e09d0d , #d707f3)" type="button" title="Send">Download Now</button>
                    </div>
                    <div class="col-md-6 my-auto" style="margin-top: 4px; display: none;" id="video-img2">
                        <img src="https://crmmrkt.com/crmmarket/uploads/image/49_Auto-Reply.jpg" class="img-fluid">
                    </div>
                    <!--3-->
                    <div class="col-md-6 my-auto text-center" id="video-card3" style="display: none;">
                        <h3>Download e-book for FREE</h3>
                        <p>Your Competitors are your guide for digital marketing 2020</p>
                        <button class="btn dowenload-btn downNow2" value="43" style="background:linear-gradient(90deg, #33a3fb , #7c07bd)" type="button" title="Send">Download Now</button>
                    </div>
                    <div class="col-md-6 my-auto" style="margin-top: 4px; display: none;" id="video-img3">
                        <img src="https://crmmrkt.com/crmmarket/uploads/image/90705_AnalyzerL.jpg" class="img-fluid">
                    </div>
                    <!--4-->
                    <div class="col-md-6 my-auto text-center" id="video-card4" style="display: none;">
                        <h3>Download e-book for FREE</h3>
                        <p>How Kids influencers can earn a lot of money from their social media</p>
                        <button class="btn dowenload-btn downNow2" value="46" style="background:linear-gradient(90deg,  #FF9800  , #f8f900 )" type="button" title="Send">Download Now</button>
                    </div>
                    <div class="col-md-6 my-auto" style="margin-top: 4px; display: none;" id="video-img4">
                        <img src="https://crmmrkt.com/crmmarket/uploads/image/32092_Family.jpg" class="img-fluid">
                    </div>
                    <!--5-->
                    <div class="col-md-6 my-auto text-center" id="video-card5" style="display: none;">
                        <h3>Download e-book for FREE</h3>
                        <p>Your quick guide to using StickyPosts in a professional way.</p>
                        <button class="btn dowenload-btn downNow2" value="49" style="background:linear-gradient(90deg, #369e36 , #c2fc03)" type="button" title="Send">Download Now</button>
                    </div>
                    <div class="col-md-6 my-auto" style="margin-top: 4px; display: none;" id="video-img5">
                        <img src="https://crmmrkt.com/crmmarket/uploads/image/5955_7 steps to add music.jpg" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="alert"></div>

    <div class="modal fade" id="response" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center" id="get">
                    Loading ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="myModal2" class="modal fade bd-example-modal-lg" role="dialog"
         style='background: rgba(0,0,0,0.7);padding-top: 60px;'>
        <div class="modal-dialog miniDialog" style="background: linear-gradient(275deg, #5e2298, #320b82); color:#fff">
            <div class="modal-header pl-2 p-1">
                <img src="../sticky/logo-s.png" style="width: 49px;z-index: 10;">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        style="position: absolute;top: 18px;right: 12px;">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-content" style="background: linear-gradient(275deg, #5e2298, #320b82); color:#fff">
                <div class="modal-body">
                    <h3 style=' color:#fff' class='text-center'> Get Resources <span
                                style="color:#f9c412; font-weight:bold">free </span></h3>
                    <div class="row my-row">
                        <div class="col-sm-7">
                            <div class="page-links nav nav-pills mb-4" id="pills-tab" role="tablist">
                                <a id="pills-home2-tab" data-toggle="pill" href="#pills-home2" role="tab"
                                   aria-controls="pills-home2" aria-selected="true"
                                   class="ml-auto mr-3 model-tabs active">Login</a>

                                <a id="pills-profile2-tab" data-toggle="pill" href="#pills-profile2" role="tab"
                                   aria-controls="pills-profile2" aria-selected="false" class='mr-3 model-tabs '>Register</a>
                            </div>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home2" role="tabpanel"
                                     aria-labelledby="pills-home2-tab">
                                    <form style="direction:ltr" class="login" method="post">

                                        <input type="hidden" name="page" class="job_name" value="">
                                        <input type="hidden" name="lang" value="en">


                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>E-mail</label>
                                            <div class="col-8">
                                                <input type="email" class="form-control" name="mail"
                                                       style="height: 24px;"
                                                       pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>Password</label>
                                            <div class="col-8">
                                                <input type="password" class="form-control" name="pass"
                                                       style="height: 24px;" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1"
                                             style="align-items:center ; width:100%;margin:auto ;justify-content:center">
                                            <div class="col-12 px-4">
                                                <a href="../sticky/forget.php?lang=en"
                                                   style="color: #fff;text-decoration: underline;">Forget password ?</a>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0  row  mt-3 text-center"
                                             style='display: flex;justify-content: center;align-items: center; flex-direction: column;'>
                                            <input class="submit mb-0 ml-0" type="submit" name="login"
                                                   style='height: 35px;border-radius: 5px; font-size: 1.5rem;font-weight: 600;background: #f9c412 !important;color: #320b82;'
                                                   id="sub" value="GET IT Now">
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="pills-profile2" role="tabpanel"
                                     aria-labelledby="pills-profile2-tab">
                                    <form style="direction:ltr" class="formres2" method="post">
                                        <input type="hidden" name="lang" value="en">
                                        <input type="hidden" name="page" class="job_name" value="">
                                        <div class="form-group row mb-1  ml-auto">
                                            <label class="col-4 p-0" style="margin: 0;font-size:12px"> <span
                                                        style="color:red">*</span>First Name</label>
                                            <div class="col-8">
                                                <input type="text" class="form-control" name="fn7" required
                                                       style="height: 24px;">
                                            </div>

                                        </div>
                                        <div class="form-group row mb-1  ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size:12px"> <span
                                                        style="color:red">*</span>Last Name</label>
                                            <div class="col-8">
                                                <input type="text" class="form-control" name="ln7" required
                                                       style="height: 24px;">
                                            </div>

                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>E-mail</label>
                                            <div class="col-8">
                                                <input type="email" class="form-control" name="em7"
                                                       style="height: 24px;"
                                                       pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 12px;"> <span
                                                        style="color:red">*</span>Password </label>
                                            <div class="col-8">
                                                <input type="password" class="form-control" name="pass" id="txtPassword"
                                                       id="txtPassword" style="height: 24px;" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 10px;"> <span
                                                        style="color:red">*</span> Confirm Pass </label>
                                            <div class="col-8">
                                                <input type="password" class="form-control" id="txtConfirmPassword"
                                                       name="Cpass" style="height: 24px;" required>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-1 ml-auto" style="align-items: center;">
                                            <label class="col-4 p-0" style="margin: 0;font-size: 10px;"> <span
                                                        style="color:red">*</span> Country </label>
                                            <div class="col-8">
                                                <select class="form-control" name="country" required>
                                                    @include('sticky.layout.partials.helpers.countries')
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group m-0"><p id="span"
                                                                       style="margin:0;color:#;font-size:10px"></p>
                                        </div>
                                        <div class="form-group mb-0  row  mt-3 text-center"
                                             style='display: flex;justify-content: center;align-items: center; flex-direction: column;'>
                                            <input class="submit mb-0 ml-0" type="submit"
                                                   style='height: 35px;border-radius: 5px; font-size: 1.5rem;font-weight: 600;background: #f9c412 !important;color: #320b82;"'
                                                   name="submit" value="GET IT Now">
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-5 pl-0 text-center"
                             style="display: flex;justify-content: center;align-items: center;">
                            <img src="assets/img/resco.png" style="width: 192px">

                        </div>
                    </div>

                </div>
                <div style="display:flex;justify-content: space-between;">
                    <small class='text-left' style="font-size:10px ;margin-left:15px">* Your Information is Safe With
                        us!</small>
                    <small class='text-right' style="font-size:10px ;margin-right:15px"><span
                                style="color:#f00">*</span> All fields are required to fill in</small>
                </div>

            </div>

        </div>
    </div>

@endsection
@push('scripts')
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script >
        page_url_ = ''
        page_url_ = '<?php echo $_SERVER['HTTP_HOST'] . strtok(strtok($_SERVER['REQUEST_URI'], '#'), '?'); ?>'


        var str = window.location.href;
        var n = str.includes("verivi");
        if(n == true){
            $('.loaders').modal('show')
            //alert($("#codedone").val());
            $('.payment-text').html($("#codedone").val());
            setTimeout(function(){$('.loaders').modal('hide');},4000);
        }
        //alert($("#codedone").val());

        $(".downNow2").click(function(){
            $("#myModal2").modal("show");
            var button = $(this).val();
            $(".job_name").val(button);
        });
        $(".closeModal").click(function(){
            $(".myModal").modal("hide");
        });


        $(document).ready(function(){
            $("#txtConfirmPassword").keyup(function(){
                $(".submit").prop('disabled',true);
                var password = $("#txtPassword").val();
                var confirmPassword = $("#txtConfirmPassword").val();
                if( password == confirmPassword){

                    $(".formres2").submit(function(e){
                        e.preventDefault(e);
                        $('.loader').modal('show');
                        $('.lds-ring').show();
                        $('.modal-body').html('....');
                        $.ajax({
                            url:"../sticky/resources.php",
                            dataType:'text',
                            type:"POST",
                            data:$(this).serialize() + '&token=' + getToken(),
                            success:function(response){
                                if(~response.indexOf('activation')){
                                    var om_elresponse = response.substring(11, response.length);
                                    var resend_link = '<a href="#" class="resend_active" data-email="'+ om_elresponse +'" onclick="resend_activation(\''+ om_elresponse +'\', \'resources\')"> Resend activation e-mail </a>';


                                    $('.lds-ring').hide();

                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will receive an email </h5><h5 style='color:#fff;line-height: 1.8;'> to confirm your email address</h5>" + resend_link);
                                }
                                else if(~response.indexOf('acti7ation')){
                                    var om_elresponse = response.substring(11, response.length);
                                    var resend_link = '<a href="#" class="resend_active" data-email="'+ om_elresponse +'" onclick="resend_activation(\''+ om_elresponse +'\', \'resources\')"> Resend activation e-mail </a>';

                                    $('.lds-ring').hide();
                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists, </h5><h5 style='color:#fff;line-height: 1.8;'> please try using another mail.</h5>" + resend_link);
                                    // setTimeout(function(){
                                    //       $('.loader').modal('hide');
                                    //   },3000)

                                }
                                else if(~response.indexOf('page')){
                                    var om_elresponse = response.substring(5, response.length);
                                    $('.lds-ring').hide();
                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will now be directed to the Resources page</h5>");

                                    if (page_url_.indexOf('Template') != -1)
                                        window.location.href = "https://stickyposts.net/sticky/TemplateEn.php?file="+om_elresponse;

                                    //   if (page_url_.indexOf('Reports'))
                                    else
                                        window.location.href = "https://stickyposts.net/sticky/ReportsEn.php?file="+om_elresponse;

                                    $("#myModals").modal("hide");

                                }
                                else if (response == 'exists000'){

                                    $('.lds-ring').hide();
                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists, </h5><h5 style='color:#fff;line-height: 1.8;'> please try using another mail.</h5>");

                                }
                                else if (response == 2){
                                    $('.lds-ring').hide();
                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists , but not activation You will receive </h5><h5 style='color:#fff;line-height: 1.8;'> an email to confirm your email address</h5>");
                                    setTimeout(function(){
                                        $('.loader').modal('hide');
                                    },3000)
                                    $("#myModals").modal("hide");
                                }
                                    // else if(response == 3){
                                    //   $('.lds-ring').hide();
                                    //   $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will now be directed to the Resources page</h5>");
                                    //   window.location.href = "https://stickyposts.net/sticky/ReportsEn.php?page=4";
                                    //   $("#myModals").modal("hide");
                                // }
                                else if (response == 4){
                                    $('.lds-ring').hide();
                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>Email Address or Password is incorrect, </h5><h5 style='color:#fff;line-height: 1.8;'> Please try again</h5> <a href='https://stickyposts.net/sticky/forget.php?lang=en' style='text-decoration:underline'>Forget Password ?</a>");
                                    $("#myModals").modal("hide");
                                }
                                else if (response == 5){
                                    $('.lds-ring').hide();
                                    $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>Please confirm your email first, To </h5><h5 style='color:#fff;line-height: 1.8;'> complete your login process in a successful way</h5>");
                                    $("#myModals").modal("hide");
                                    setTimeout(function(){
                                        $('.loader').modal('hide');
                                    },3000)
                                }

                            }
                        })
                    });

                    //     $(".formres2").submit(function(e){
                    //     e.preventDefault(e);
                    //     $('.loaders').modal('show');
                    //     $('.lds-ring').show();
                    //     $('.payment-text').html('....');
                    //     $.ajax({
                    //         url:"../sticky/resources.php",
                    //         dataType:'json',
                    //         type:"POST",
                    //         data:$(this).serialize(),
                    //         success:function(response){
                    //             if(response == 1){
                    //                 $('.lds-ring').hide();
                    //                 $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>You will receive an email </h5><h5 style='color:#fff;line-height: 1.8;'> to confirm your email address</h5>");
                    //             //   setTimeout(function(){
                    //             //       window.location.href = "../sticky/thanks-en.php?page="+<?php //echo $page45?>;
                    //             //   },2000)
                    //             }
                    //             else if (response == 0){
                    //               $('.lds-ring').hide();
                    //               $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists, </h5><h5 style='color:#fff;line-height: 1.8;'> please try using another mail.</h5>");
                    //                 $("#myModals").modal("hide");
                    //             }
                    //             else if (response == 2){
                    //               $('.lds-ring').hide();
                    //               $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists , but not activation You will receive </h5><h5 style='color:#fff;line-height: 1.8;'> an email to confirm your email address</h5>");
                    //                 $("#myModals").modal("hide");
                    //             }
                    //             else if(response == 3){
                    //               $('.lds-ring').hide();
                    //               $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>You will now be directed to the Resources page</h5>");
                    //               window.location.href = "../sticky/ReportsEn.php?name&page="+<?php echo $page45?>;
                    //               $("#myModals").modal("hide");
                    //             }
                    //             else if (response == 4){
                    //               $('.lds-ring').hide();
                    //               $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>Email Address or Password is incorrect, </h5><h5 style='color:#fff;line-height: 1.8;'> Please try again</h5> <a href='../sticky/forget.php?lang=en' style='text-decoration:underline'>Forget Password ?</a>");
                    //                 $("#myModals").modal("hide");
                    //             }
                    //             else if (response == 5){
                    //               $('.lds-ring').hide();
                    //               $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>Please confirm your email first, To </h5><h5 style='color:#fff;line-height: 1.8;'> complete your login process in a successful way</h5>");
                    //               $("#myModals").modal("hide");
                    //           }
                    //         },
                    //          error: function (error){
                    //                 $('.lds-ring').hide();
                    //                 $('.payment-text').html('please try again');
                    //           }
                    //     })
                    // });
                    console.log(password);
                    $("#span").html("");
                    $(".submit").prop('disabled',false);
                }
                else{
                    $("#span").html("Passwords do not match.");
                    $(".submit").prop('disabled',true);
                }

            });

            $(".login").submit(function(e){
                e.preventDefault(e);
                $('.loader').modal('show');
                $('.lds-ring').show();
                $('.modal-body').html('....');
                $.ajax({
                    url:"../sticky/resources.php",
                    dataType:'text',
                    type:"POST",
                    data:$(this).serialize(),
                    success:function(response){
                        if(response == 1){
                            $('.lds-ring').hide();
                            $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will receive an email </h5><h5 style='color:#fff;line-height: 1.8;'> to confirm your email address</h5>");
                            //   setTimeout(function(){
                            //       window.location.href = "https://stickyposts.net/sticky/thanks-en.php?page="+<?php //echo $page45?>;
                            //   },2000)
                        }
                        else if (response == 0){
                            $('.lds-ring').hide();
                            $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists, </h5><h5 style='color:#fff;line-height: 1.8;'> please try using another mail.</h5>");
                            $("#myModals").modal("hide");
                        }
                        else if (response == 2){
                            $('.lds-ring').hide();
                            $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists , but not activation You will receive </h5><h5 style='color:#fff;line-height: 1.8;'> an email to confirm your email address</h5>");
                            $("#myModals").modal("hide");
                        }
                            // else if(response == 3){
                            //   $('.lds-ring').hide();
                            //   $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will now be directed to the Resources page</h5>");
                            //   window.location.href = "https://stickyposts.net/sticky/ReportsEn.php?page=4";
                            //   $("#myModals").modal("hide");
                        // }
                        else if (response == 4){
                            $('.lds-ring').hide();
                            $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>Email Address or Password is incorrect, </h5><h5 style='color:#fff;line-height: 1.8;'> Please try again</h5> <a href='https://stickyposts.net/sticky/forget.php?lang=en' style='text-decoration:underline'>Forget Password ?</a>");
                            $("#myModals").modal("hide");
                        }
                        else if (response == 5){
                            $('.lds-ring').hide();
                            $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>Please confirm your email first, To </h5><h5 style='color:#fff;line-height: 1.8;'> complete your login process in a successful way</h5>");
                            $("#myModals").modal("hide");
                        }
                        else if(~response.indexOf('page')){
                            var om_elresponse = response.substring(5, response.length);
                            $('.lds-ring').hide();
                            $('.modal-body').html("<h5 style='color:#fff;line-height: 1.8;'>You will now be directed to the Resources page</h5>");

                            if (page_url_.indexOf('Template') != -1)
                                window.location.href = "https://stickyposts.net/sticky/TemplateEn.php?file="+om_elresponse;

                            //   if (page_url_.indexOf('Reports'))
                            else
                                window.location.href = "https://stickyposts.net/sticky/ReportsEn.php?file="+om_elresponse;

                            //   window.location.href = "https://stickyposts.net/sticky/ReportsEn.php?file="+om_elresponse;
                            $("#myModals").modal("hide");

                        }
                    }
                })
            });


//   $(".login").submit(function(e){
//             e.preventDefault(e);
//             $('.loaders').modal('show');
//             $('.lds-ring').show();
//             $('.payment-text').html('....');
//             $.ajax({
//                 url:"../sticky/resources.php",
//                 dataType:'json',
//                 type:"POST",
//                 data:$(this).serialize(),
//                 success:function(response){
//                     if(response == 1){
//                         $('.lds-ring').hide();
//                         $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>You will receive an email </h5><h5 style='color:#fff;line-height: 1.8;'> to confirm your email address</h5>");
//                     //   setTimeout(function(){
//                     //       window.location.href = "../sticky/thanks-en.php?page="+<?php //echo $page45?>;
//                     //   },2000)
//                     }
//                     else if (response == 0){
//                       $('.lds-ring').hide();
//                       $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists, </h5><h5 style='color:#fff;line-height: 1.8;'> please try using another mail.</h5>");
//                         $("#myModals").modal("hide");
//                     }
//                     else if (response == 2){
//                       $('.lds-ring').hide();
//                       $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists , but not activation You will receive </h5><h5 style='color:#fff;line-height: 1.8;'> an email to confirm your email address</h5>");
//                         $("#myModals").modal("hide");
//                     }
//                     else if(response == 3){
//                       $('.lds-ring').hide();
//                       $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>You will now be directed to the Resources page</h5>");
//                       window.location.href = "../sticky/ReportsEn.php?name&page="+<?php echo $page45?>;
//                       $("#myModals").modal("hide");
//                     }
//                     else if (response == 4){
//                       $('.lds-ring').hide();
//                       $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>Email Address or Password is incorrect, </h5><h5 style='color:#fff;line-height: 1.8;'> Please try again</h5> <a href='../sticky/forget.php?lang=en' style='text-decoration:underline'>Forget Password ?</a>");
//                         $("#myModals").modal("hide");
//                     }
//                     else if (response == 5){
//                       $('.lds-ring').hide();
//                       $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>Please confirm your email first, To </h5><h5 style='color:#fff;line-height: 1.8;'> complete your login process in a successful way</h5>");
//                       $("#myModals").modal("hide");
//                   }
//                 },
//                  error: function (error){
//                         $('.lds-ring').hide();
//                         $('.payment-text').html('please try again');
//                   }

//             })
//         });
        });

        $('#active_code_form').submit(function(e){
            $('.loaders').modal('show');
            $('.lds-ring').show();
            $('.payment-text').html('....');
            e.preventDefault();

            $.ajax({
                url:    'ajax2.php',
                method:   'POST',
                dataType:   'text',
                data:   $(this).serialize() ,
                success : function(response)
                {$('.payment-text').html(response);},
                error: function (error){
                    $('.lds-ring').hide();
                    $('.payment-text').html('please try again');
                }
            });

        });

        $('#form1').submit(function(e){

            e.preventDefault();

            $.ajax({
                url:    'ajax3.php',
                method:   'POST',
                dataType:   'text',
                data:   $(this).serialize() ,
                success : function(response)
                {$('.payment-text').html('Done');},
                error: function (error){
                    $('.lds-ring').hide();
                    $('.payment-text').html('please try again');
                }
            });
            $('.loaders').modal('show');
            $('.lds-ring').show();
            $('.payment-text').html('....');

        });

        $(".menu-toggler").click(function(){
            $(".main-navigation").slideToggle(500);
        });
        $("#nav-btn").click(function(){
            $("#main-nav-bar").show("slow");
            $("#nav-btn").hide("slow");
            $("#close-nav-btn").show("slow");
        });
        $("#close-nav-btn").click(function(){
            $("#main-nav-bar").hide("slow");
            $("#nav-btn").show("slow");
            $("#close-nav-btn").hide("slow");
        });



        $("#video-card2").hide();
        $("#video-img2").hide();
        $("#video-card3").hide();
        $("#video-img3").hide();
        $("#video-card4").hide();
        $("#video-img4").hide();
        $("#video-card5").hide();
        $("#video-img5").hide();
        $(document).ready(function(){
            $(".title").click(function(){
                document.getElementById("content").innerHTML ='<div class="card-header text-center text-dark p-0" style="background:linear-gradient(90deg,#320b82,#9c33c3);height:36px;color:#fff"><h3 style="margin: 0;color:#fff">Sticky Posts</h3></div><article class="stack__card stack__card__right"><figure class="span__40"> <img class="lazyload" style="padding: 20px 10px;"src="../../portal.png" alt="Descriptive Text"></figure><div class="stack__card__content" dir="ltr"><h2 class="stack__card__title text-center">Schedule, Publish and Rate</h2><p>Register with Sticky Posts’ automated scheduling service to plan and publish on all your social media platforms at once from any place. </p></div></article>';
                $("#video-card").show();
                $("#video-img").show();
                $(".stickycov").siblings().hide();
            })

            $(".ANALYZE").click(function(){
                document.getElementById("content").innerHTML ='<div class="card-header text-center text-dark p-0" style="background:linear-gradient(90deg, #33a3fb 0%, #7c07bd 100%);height:36px;color:#fff"><h3 style="margin: 0;color:#fff">Competitors & Influencers </h3></div><article class="stack__card stack__card__right"><figure class="span__40"> <img class="lazyload" style="padding: 20px 10px;" src="../../Competitors.png" alt="Descriptive Text"></figure><div class="stack__card__content" dir="ltr"><h2 class="stack__card__title text-center">Follow up, analyze, and compete</h2><p>Participate in competitors’ tracking service in order to plan your activities in a more professional way based on detailed reports and results, which will bring you closer to your target audience.</p></div></article>';
                $("#video-card").hide();
                $("#video-img").hide();
                $("#video-card2").hide();
                $("#video-img2").hide();
                $("#video-card4").hide();
                $("#video-img4").hide();
                $("#video-card5").hide();
                $("#video-img5").hide();
                $("#video-card3").show();
                $("#video-img3").show();
            });
            $(".FAMILY").click(function(){

                document.getElementById("content").innerHTML ='<div class="card-header text-center text-dark p-0" style="background:linear-gradient(90deg, #FF9800 , #f8f900);height:36px;"><h3 style="margin: 0;color:#fff">Family Service </h3></div><article class="stack__card stack__card__right"><figure class="span__40"> <img class="lazyload" style="padding: 20px 10px;"src="../../family.png" alt="Descriptive Text"></figure><div class="stack__card__content" dir="ltr"><h2 class="stack__card__title text-center">Your family is now secure</h2><p>for the first time in the world, Sticky Posts offers innovative modern methods of online investing using artificial intelligence to assure a secure and luxurious life for families. </p></div></article>';
                $("#video-card2").hide();
                $("#video-img2").hide();
                $("#video-card5").hide();
                $("#video-img5").hide();
                $("#video-card3").hide();
                $("#video-img3").hide();
                $("#video-card").hide();
                $("#video-img").hide();
                $("#video-card4").show();
                $("#video-img4").show();
            });
            $(".AUTOACTIVITY").click(function(){

                document.getElementById("content").innerHTML ='<div class="card-header text-center text-dark p-0" style="background:linear-gradient(90deg, #e09d0d, #d707f3);height:36px;"><h3 style="margin: 0;color:#fff">Auto Reply  </h3></div><article class="stack__card stack__card__right"><figure class="span__40"> <img class="lazyload" style="padding: 20px 10px;"src="../../autoactivity.png" alt="Descriptive Text"></figure><div class="stack__card__content" dir="rtl"><h2 class="stack__card__title text-center">More Engagement, More Credibility </h2><p>Manage your interactions with your audience & followers which allows you to build your identity .Auto-Reply Service provides comments reply, Messages reply , black list option & more. </p></div></article>';
                $("#video-card").hide();
                $("#video-img").hide();
                $("#video-card3").hide();
                $("#video-img3").hide();
                $("#video-card5").hide();
                $("#video-img5").hide();
                $("#video-card4").hide();
                $("#video-img4").hide();
                $("#video-card2").show();
                $("#video-img2").show();
            });
            $(".ACTIVE").click(function(){

                document.getElementById("content").innerHTML ='<div class="card-header text-center text-dark p-0" style="background:linear-gradient(90deg, #369e36 , #c2fc03);height:36px;"><h3 style="margin: 0;color:#fff">Activation  </h3></div><article class="stack__card stack__card__right"><figure class="span__40"> <img class="lazyload" style="padding: 20px 10px;"src="../../Box.png" alt="Descriptive Text"></figure><div class="stack__card__content" dir="ltr"><h2 class="stack__card__title text-center">3 steps to get you started </h2><p>This service is available to all our customers who have subscriptions to our services from e-commerce platforms or partners in any store. Follow these steps to get started: </p> <ol> <li>- Activate the subscription by filling the data here </li><li>- Login to your dashboard </li><li>- Start scheduling your business and all your </li></ol></div></article>';
                $("#video-card2").hide();
                $("#video-img2").hide();
                $("#video-card3").hide();
                $("#video-img3").hide();
                $("#video-card4").hide();
                $("#video-img4").hide();
                $("#video-card").hide();
                $("#video-img").hide();
                $("#video-card5").show();
                $("#video-img5").show();
            });
        });

        $(document).ready(function(){


            $(".box").slideUp();

            $('.form').submit(function(e){
                zone = '';
                if ($(this).data('zone'))
                    zone = $(this).data('zone');
                $("#submit").prop('disabled',true);

                $('.loaders').modal('show');
                $('.lds-ring').show();
                $('.payment-text').html('....');
                e.preventDefault();
                form_data = $(this).serialize();

                $.ajax({
                    url:    'ajax.php',
                    method:   'POST',
                    dataType:   'json',
                    data:   $(this).serialize() + '&token=' + getToken(),
                    success : function(data)
                    {
                        if(data['state'] == 'error')
                        {
                            $("#submit").prop('disabled',false);
                            $('.lds-ring').hide();
                            $('.payment-text').html('<h4>This email already exists, please try using another mail.</h4>');
                            if (zone == 'analyzer'){

                                $.ajax({
                                    url:    'ajax.php',
                                    method:   'POST',
                                    dataType:   'text',
                                    data:   form_data + '&get_points_analyzer=1',
                                    success : function(data2)
                                    {
                                        if (data2.indexOf('###nopoints###') !== -1){
                                            $("#submit").prop('disabled',false);
                                            $('.lds-ring').hide();
                                            $('.payment-text').html('<h4>This email already exists , please subscribe to this service.</h4>');
                                            var url = 'https://stickyposts.net/stickypost_register/payment-en.php?user_id=2062&type=analyzer&state=upgrade&analyzer_id=424';
                                            setTimeout(function(){window.location.href= url;},2000)
                                        }

                                    }
                                });
                            }
                        }
                        else if (data['state'] == 'new')
                        {
                            if(data['goto'] == 'analyzer')
                            {
                                $('.payment-text').html('<h5>The registration is successful</h5>');
                                var url = 'https://stickyposts.net/phpanalyzer/product3/login';
                                setTimeout(function(){window.location.href= url;},2000)
                            }

                            if(data['goto'] == 'sticky')
                            {
                                $('.payment-text').html('<h5>The registration is successful, and you will be directed to the payment page</h5>');
                                var my_promo = $('#prom_code').val();
                                var url = 'payment-en.php?user_id='+data['user_id']+'&state='+data['state']+'&type='+data['goto']+'&promo='+my_promo ;
                                setTimeout(function(){window.location.href= url;},2000)
                            }
                            if(data['goto'] == 'autoactivity')
                            {
                                $('.payment-text').html('<h5>The registration is successful, and you will be directed to the payment page</h5>');
                                var my_promo = $('#prom_code').val();
                                var url = 'payment-en.php?user_id='+data['user_id']+'&state='+data['state']+'&type='+data['goto']+'&promo='+my_promo ;
                                setTimeout(function(){window.location.href= url;},2000)
                            }
                            if(data['goto'] == 'family')
                            {
                                $('.payment-text').html('<h5>The registration is successful, and you will be directed to the payment page</h5>');
                                var url = 'payment-en.php?user_id='+data['user_id']+'&state='+data['state']+'&type='+data['goto'] ;
                                setTimeout(function(){window.location.href= url;},2000)
                            }
                        }

                    },
                    error: function (error){
                        $("#submit").prop('disabled',false);
                        $('.lds-ring').hide();
                        $('.payment-text').html('please try again');
                    }
                });


            });


        });



    </script>

    <script>  var panel = $('.at-accordion__panel');

        panel.click( function(){
            // console.log('click');
            panel.removeClass('is-open');

            $(this).addClass('is-open');
        });


    </script>

    <script type="text/javascript">

        //start event

        $('.formevent').submit(function(e){
            $('.loaders').modal('show');
            $('.lds-ring').show();
            $('.payment-text').html('....');
            e.preventDefault();

            $.ajax({
                url:    'https://stickyposts.net/sticky/eventajaxen.php',
                method:   'POST',
                dataType:   'text',
                data:   $(this).serialize() + '&token=' + getToken(),
                success : function(response)
                {
                    if(~response.indexOf('activation')){
                        console.log('activation');
                        var om_elresponse = response.substring(11, response.length);
                        var resend_link = '<a href="#" class="resend_active" data-email="'+ om_elresponse +'" onclick="resend_activation(\''+ om_elresponse +'\', \'event\')"> Resend activation e-mail </a>';


                        $('.lds-ring').hide();

                        $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>You will receive an email </h5><h5 style='color:#fff;line-height: 1.8;'> to confirm your email address</h5>" + resend_link);
                    }
                    else if(~response.indexOf('acti7ation')){
                        var om_elresponse = response.substring(11, response.length);
                        var resend_link = '<a href="#" class="resend_active" data-email="'+ om_elresponse +'" onclick="resend_activation(\''+ om_elresponse +'\', \'event\')"> Resend activation e-mail </a>';

                        $('.lds-ring').hide();
                        $('.payment-text').html("<h5 style='color:#fff;line-height: 1.8;'>This email already exists, </h5><h5 style='color:#fff;line-height: 1.8;'> please try using another mail.</h5>" + resend_link);
                        // setTimeout(function(){
                        //       $('.loader').modal('hide');
                        //   },3000)

                    }

                }
            })
        });
        // end event
    </script>

@endpush
