@extends('sticky.layout.master')
@push('head')
    <style>

        }
        .header {
            background: -webkit-linear-gradient(#320b82, #9c33c3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 800;
        }

        #email {
            border: 1px solid #dfdfdf;
        }

        li p {
            max-width: 100%;
        }

        .dowenload-btn {
            margin-top: 1.5px;
        }

        .formee .right {
            text-transform: initial;
        }

        .get-vedio-form {
            left: 0;
            right: initial;
        }

        #email {
            border: none;
            background-color: #f3f3f3;
            box-shadow: 0 5px 10px rgba(0, 0, 0, .1);
            color: #222;
            height: 35px;
        }

        @media (max-width: 567px) {
            #signup {
                margin-left: 0;
                display: flex;
            }

            .get-vedio-form {
                position: relative;
            }

            #email {
                min-width: 100px !important;
            }

            .cards #email {
                min-width: 200px !important;
            }

            .know-more {
                width: 100%;
                margin-left: 0;
            }

            .formee .right {
                height: 35px;
                width: 40%;
            }

        }

        @media (min-width: 568px) {
            .know-more {
                width: 29%;
                margin-left: 0;
            }

            .formee .right {
                height: 35px;
                width: 30%;
            }

        }

        .btn-cont-ar {
            width: 91%;
            text-align: left !important;
            margin: 5px auto 0;
        }

        .btn-cont-ar .dowenload-btn {
            background: #212F63;
            margin-top: 5px;
            width: 100%;
            margin-left: 0;
        }

    </style>

@endpush
@section('body')
    @include('sticky.layout.partials.common.homeBanner')
    <div class="">
        <div class='m-auto'>
            <h2 class='text-center  mt-3' style="color:#320b82">{{__('more-h1-text')}}</h2>
        </div>
        <div class='cards' id='card1'>

            <div class='video-card my-3'>
                <div class='row my-row'>
                    <div class='col-md-9'>
                        <h2 style='color:#391B7F'> {{__('more-idh21')}} </h2>
                        <ul>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan1')}} </span> {{__('more-idp1')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan2')}}  </span>{{__('more-idp2')}}
                                </p></li>

                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan3')}} </span> {{__('more-idp3')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan4')}} </span> {{__('more-idp4')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan5')}}  </span>{{__('more-idp5')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan6')}} </span> {{__('more-idp6')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan7')}}</span> {{__('more-idp7')}}
                                </p></li>

                        </ul>
                        <button class='btn dowenload-btn ml-md-3 know-more' onclick="Readmore3()"
                                id="myBtn3">{{__('more-idbtn1')}}</button>
                        <form id="signup" class="formee get-vedio-form signuptrial" method="post">
                            <input class="right inputnew" type="submit" title="Send" value="{{__('more-idvalue1')}}"
                                   style="background: #382B7D !important;border-radius: 5px 0 0 5px;height: 35px;padding: 0px 11px;"/>
                            <input name="email" class='input' id="email" type="text" placeholder='{{__('more-idbtn2')}}'
                                   style="border-radius: 0 5px 5px 0;margin-left: -4px;"/>
                            <input name="type" value="Electronic commerce owners" type="hidden">
                        </form>

                    </div>
                    <div class='col-md-3 text-center'>
                        <div class='img-cont'>
                            <img class='img-fluid' src=''>
                        </div>
                        <div class="btn-cont-ar">
                            <a class="btn dowenload-btn ml-3" href="'.$link.'" style="background: #382B7D !important;"
                               title="Send" download>Download</a>
                            <button class="btn dowenload-btn job-btn" value="'.$file_id.'"
                                    style="background: #382B7D !important;" type="submit" title="Send">Download
                            </button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='cards' id='card2'>

            <div class='video-card my-3'>
                <div class='row my-row'>
                    <div class='col-md-9'>
                        <h2 style='color:#391B7F'> {{__('more-idh22')}} </h2>
                        <ul>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;"> {{__('more-idspan8')}} </span> {{__('more-idp8')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan9')}} </span> {{__('more-idp9')}}
                                </p></li>
                            <span id="more4">
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;"> {{__('more-idspan3')}}</span> {{__('more-idp10')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan4')}}</span> {{__('more-idp11')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan2')}} </span>{{__('more-idp12')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan6')}} </span> {{__('more-idp13')}} </p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan7')}} </span>  {{__('more-idp7')}}</p></li>
                                </span>
                        </ul>
                        <button class='btn dowenload-btn ml-md-3 know-more' onclick="Readmore4()"
                                id="myBtn4"> {{__('more-idbtn1')}}</button>
                        <form id="signup" class="formee get-vedio-form signuptrial" method="post">
                            <input class="right inputnew" type="submit" title="Send" value="{{__('more-idvalue1')}}"
                                   style="background: #6B2C76 !important;border-radius: 5px 0 0 5px;height: 35px;padding: 0px 11px;padding: 0px 11px;"/>
                            <input name="email" class='input' id="email" type="text" placeholder='{{__('more-idbtn2')}}'
                                   style="border-radius: 0 5px 5px 0;margin-left: -4px;"/>
                            <input name="type" value="Influences-Bloggers-Users" type="hidden">
                        </form>

                    </div>
                    <div class='col-md-3 text-center'>
                        <div class='img-cont'>
                            <img class='img-fluid' src="">
                        </div>
                        <div class="btn-cont-ar">

                            <a class="btn dowenload-btn ml-3" href="'.$link.'" style="background: #6B2C76 !important;"
                               title="Send" download>Download</a>


                            <button class="btn dowenload-btn job-btn" value="'.$file_id.'"
                                    style="background: #6B2C76 !important;" type="submit" title="Send">Download
                            </button>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class='cards' id='card3'>

            <div class='video-card my-3'>
                <div class='row my-row'>
                    <div class='col-md-9'>
                        <h2 style='color:#391B7F'>  {{__('more-idh23')}}</h2>
                        <ul>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan12')}} </span> {{__('more-idp14')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan9')}}</span> {{__('more-idp9')}}
                                </p></li>
                            <span id="more5">
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan4')}}</span> {{__('more-idp15')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan2')}} </span> {{__('more-idp16')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan1')}} </span> {{__('more-idp17')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan6')}}  </span>{{__('more-idp13')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan7')}}</span>  {{__('more-idp7')}}</p></li>
                                </span>
                        </ul>
                        <button class='btn dowenload-btn ml-md-3 know-more' onclick="Readmore5()"
                                id="myBtn5">{{__('more-idbtn1')}}</button>
                        <form id="signup" class="formee get-vedio-form signuptrial" method="post">
                            <input class="right inputnew"
                                   style='background: #212F63 !important;border-radius: 5px 0 0 5px;height: 35px;padding: 0px 11px;'
                                   type="submit" title="Send" value="{{__('more-idvalue1')}}"/>
                            <input name="email" class='input' id="email" type="text" placeholder='{{__('more-idbtn2')}}'
                                   style="border-radius: 0 5px 5px 0;margin-left: -4px;"/>
                            <input name="type" value="Companies and Trademarks" type="hidden">
                        </form>

                    </div>
                    <div class='col-md-3 text-center'>

                        <div class='img-cont'>
                            <img class='img-fluid' src="">
                        </div>
                        <div class="btn-cont-ar">

                            <a class="btn dowenload-btn ml-3" href="'.$link.'" style="background: #212F63 !important;"
                               title="Send" download>Download</a>

                            <button class="btn dowenload-btn job-btn" value="'.$file_id.'"
                                    style="background: #212F63 !important;" type="submit" title="Send">Download
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='cards' id='card4'>

            <div class='video-card my-3'>
                <div class='row my-row'>
                    <div class='col-md-9'>
                        <h2 style='color:#391B7F'>  {{__('more-idh24')}}</h2>
                        <ul>
                            <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{__('more-idspan22')}} </span> {{__('more-idp20')}}
                                </p></li>

                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan2')}}</span> {{__('more-idp2')}}
                                </p></li>
                            <span id="more6">
                                  <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">  {__('more-idspan23')}} </span> {{__('more-idp23')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan4')}}</span> {{__('more-idp4')}}.</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">Team Performance:</span>{{__('more-idp5')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan6')}} </span> {{__('more-idp13')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan7')}}</span> {{__('more-idp7')}}</p></li>
                                </span>
                        </ul>
                        <button class='btn dowenload-btn ml-md-3 know-more' onclick="Readmore6()"
                                id="myBtn6">{{__('more-idbtn1')}}</button>
                        <form id="signup" class="formee get-vedio-form signuptrial" method="post">
                            <input class="right inputnew"
                                   style='background: #9362A6 !important;border-radius: 5px 0 0 5px;height: 35px;padding: 0px 11px;'
                                   type="submit" title="Send" value="{{__('more-idvalue1')}}"/>
                            <input name="email" class='input' id="email" type="text" placeholder='{{__('more-idbtn2')}}'
                                   style="border-radius: 0 5px 5px 0;margin-left: -4px;"/>
                            <input name="type" value="NGOs Governments entities" type="hidden">
                        </form>

                    </div>
                    <div class='col-md-3 text-center'>
                        <!--<img class='img-fluid' src='images/b.jpg'>-->
                        <div class='img-cont'>
                            <img class='img-fluid' src=''>
                        </div>
                        <div class="btn-cont-ar">
                            if(isset($_SESSION['resources_login']))
                            {
                            $link = $file_url;
                            echo '<a class="btn dowenload-btn ml-3" href="'.$link.'"
                                     style="background: #9362A6 !important;" title="Send" download>Download</a>';

                            }
                            else{
                            echo '
                            <button class="btn dowenload-btn job-btn" value="'.$file_id.'"
                                    style="background: #9362A6 !important;" type="submit" title="Send">Download
                            </button>
                            ';

                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='cards' id='card5'>

            <div class='video-card my-3'>
                <div class='row my-row'>
                    <div class='col-md-9'>
                        <h2 style='color:#391B7F'>  {{__('more-idh25')}}</h2>
                        <ul>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan12')}}  </span> {{__('more-idp21')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan2')}} </span> {{__('more-idp2')}}
                                </p></li>
                            <span id="more1">
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">  {{__('more-idspan24')}} </span> {{__('more-idp25')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan4')}}</span>{{__('more-idp4')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan5')}}</span>{{__('more-idp5')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan6')}} </span> {{__('more-idp13')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan7')}}</span> {{__('more-idp7')}}</p></li>
                                </span>
                        </ul>
                        <button class='btn dowenload-btn ml-md-3 know-more' onclick="Readmore1()"
                                id="myBtn1">{{__('more-idbtn1')}}</button>
                        <form id="signup" class="formee get-vedio-form signuptrial" method="post">
                            <input class="right inputnew"
                                   style='background: #34A9DA !important;border-radius: 5px 0 0 5px;height: 35px;padding: 0px 11px;'
                                   type="submit" title="Send" value="{{__('more-idvalue1')}}"/>
                            <input name="email" class='input' id="email" type="text" placeholder='{{__('more-idbtn2')}}'
                                   style="border-radius: 0 5px 5px 0;margin-left: -4px;"/>
                            <input name="type" value="Advertising & Media Agencies" type="hidden">
                        </form>

                    </div>
                    <div class='col-md-3 text-center'>
                        <!--<img class='img-fluid' src='images/b.jpg'>-->
                        <div class='img-cont'>
                            <img class='img-fluid' src="">

                        </div>
                        <div class="btn-cont-ar">
                            if(isset($_SESSION['resources_login']))
                            {
                            $link = $file_url;
                            echo '<a class="btn dowenload-btn ml-3" href="'.$link.'"
                                     style="background: #34A9DA !important;" title="Send" download>Download</a>';

                            }
                            else{
                            echo '
                            <button class="btn dowenload-btn job-btn" value="'.$file_id.'"
                                    style="background: #34A9DA !important;" type="submit" title="Send">Download
                            </button>
                            ';

                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='cards' id='card6'>
            $page49 = "205";

            // $downloads10 = $conn8->query("SELECT * FROM `resources` WHERE lang='en' AND page = '$page49' AND status =
            '1' AND project = 'stickypost'");
            // while ($row10 = $downloads10->fetch()) {
            // $file_id = $row10['id'];
            // $file_url = $row10['files'];
            // $file_img5 = $row10['imagec'];
            // $counter = $row10['count'];

            // }

            $total_counts = 0;
            $file_id = $response['data'][$zone_freelance]['id'];
            $file_url = $response['data'][$zone_freelance]['file_url'];
            $file_img5 = $response['data'][$zone_freelance]['cover_portrait_url'];
            $total_counts = $response['data'][$zone_freelance]['total_downloads'];


            ?>
            <div class='video-card my-3'>
                <div class='row my-row'>
                    <div class='col-md-9'>
                        <h2 style='color:#391B7F'> {{__('more-idh26')}}</h2>
                        <ul>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan2')}} </span> {{__('more-idp40')}}
                                </p></li>
                            <li><p>
                                    <span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan4')}} </span>{{__('more-idp4')}}
                                </p></li>
                            <span id="more2">
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;"> {{__('more-idspan1')}} </span> {{__('more-idp41')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;"> {{__('more-idspan3')}}</span> {{__('more-idp3')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan5')}}</span>{{__('more-idp5')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan6')}} </span> {{__('more-idp13')}}</p></li>
                                <li><p><span style="font-size:14px ;font-weight: bold;color: #9c33c3;">{{__('more-idspan7')}} </span>  {{__('more-idp7')}}</p></li>
                                </span>
                        </ul>
                        <button class='btn dowenload-btn ml-md-3 know-more' onclick="Readmore2()"
                                id="myBtn2">{{__('more-idbtn1')}}</button>
                        <form id="signup" class="formee get-vedio-form signuptrial" method="post">
                            <input class="right inputnew"
                                   style='background: #0B70AE  !important;border-radius: 5px 0 0 5px;height: 35px;padding: 0px 11px;'
                                   type="submit" title="Send" value="{{__('more-idvalue1')}}"/>
                            <input name="email" class='input' id="email" type="text" placeholder='{{__('more-idbtn2')}}'
                                   style="border-radius: 0 5px 5px 0;margin-left: -4px;"/>
                            <input name="type" value="Freelancers & Job Seekers" type="hidden">
                        </form>

                    </div>
                    <div class='col-md-3 text-center'>
                        <!--<img class='img-fluid' src='images/b.jpg'>-->
                        <div class='img-cont'>
                            <img class='img-fluid' src="">
                        </div>
                        <div class="btn-cont-ar">

                            <a class="btn dowenload-btn ml-3" href="'.$link.'" style="background: #0B70AE !important;"
                               title="Send" download>Download</a>

                            <button class="btn dowenload-btn job-btn" value="'.$file_id.'"
                                    style="background: #0B70AE !important;" type="submit" title="Send">Download
                            </button>

                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

@endsection

@push('scripts')
    <script>
        $(".job-btn").click(function () {
            $("#myModal").modal('show');
        })
        $(".job-btn").click(function () {
            var button = $(this).val();
            $(".job_name").val(button);
            $("#job_id").val($(this).data('id'))
        });


        $("#nav-btn").click(function () {
            $("#main-nav-bar").show("slow");
            $("#nav-btn").hide();
            $("#close-nav-btn").show();
        });
        $("#close-nav-btn").click(function () {
            $("#main-nav-bar").hide("slow");
            $("#nav-btn").show();
            $("#close-nav-btn").hide();
        });

        $('.download_resource_assign').on('click', function () {

            resource_id = $(this).attr('data-id');

            $('.file_resource').val(resource_id);

        });

    </script>
@endpush
