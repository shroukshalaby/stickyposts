@extends('sticky.layout.master')

@section('title','Family Package StickyPosts')

@section('page-wrapper')




@endsection



@section('body')


@endsection





<html>
<head>
    <meta charset="UTF-8">

    <title>Family Package StickyPosts</title>
    <?php include "includes/header-en.php" ?>

    <link rel="stylesheet" href="css/style_english.css">
    <link rel="stylesheet" href="css/small-device.css">

    <style>
        .site-header{
            background:linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);
        }
        .slick-slide{
            height:auto !important;
        }
        .about{
            border:none;
        }
        .box_shadow_height{
            height:140px;
        }
        .box_shadow{
            background:#fff;
            padding: 10px;
            -webkit-box-shadow: 0px 0px 19px -4px rgba(47,22,126,1);
            -moz-box-shadow: 0px 0px 19px -4px rgba(47,22,126,1);
            box-shadow: 0px 0px 19px -4px rgba(47,22,126,1);
            border-radius:10px;
        }

        .pricing-style-one .tab-title li a{
            border-radius:5px !important;
        }
        .section-head {
            position: relative;
            padding: 0;
            color: #320b82;
            letter-spacing: -1px;
            font-size: 24px;
            font-weight: 700;
            text-align: center;
            text-transform: none;
            padding-top: 26px;
        }
        #features li{
            border-radius:10px;
        }
        .black-color{
            color:#030300;
        }
        .card-header p{
            color:#320b82 !important;
        }
        .card-body label{
            color:#320b82 !important;
        }
        .card-footer{
            color:#320b82 !important;
        }
        .highlights-phone.wht .phone-holder #fon{
            background:url(images/phone-black.png) center top no-repeat;
        }
        .phone-holder {
            display: block;
            height: 100%;
            position: relative;
            top: 22px;
            left: -2px;
            width: 259px;
            margin: auto;
            overflow: hidden;
        }
        .hgi img{
            width:100%;
            height:421px;
            margin-left:0;
        }
        .highlights-phone.wht .hgi{
            top:19px;
        }
        .card{
            background:linear-gradient(0deg, #FF9800 , #f8f900) !important;
        }
        .content{
            color: #000;
            padding: 10px;
            border-radius: 5px;
            color:#fff;
            background:linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);
        }
        #features li{
            margin:55px 0;
        }
        @media(max-width:767px){
            .col-rev{
                flex-direction: column-reverse !important;
                margin-top:5rem !important;
                padding-right:22px !important;
            }
        }
        .more{
            font-size: 16px;
            color: #320b82;
            text-decoration: underline;
            cursor: pointer;
            font-weight: bold;
        }
        .content p{
            margin:0;
            text-align:center;
        }
        .content a{
            color:#fff;
        }
        .number-circle{
            width:50px;
            height:50px;
            border-radius:50%;
            background:linear-gradient(-145deg, #320b82 0%, #9c33c3 100%);
            color:#fff;
            text-align:center;
            line-height:3;
        }
        .features-left li img, .features-right li img {

            top: 10px;
        }
        #features li {
            height: 105px;
        }
    </style>
</head>
<body>
<?php include "includes/navEn.php" ?>
<div class="banner" style="background:#f8f900;padding:100px 0 0">
    <div class="row m-0  col-rev hide-mobile" style="">
        <div class="col-md-6 text-left mt-1 pl-4" dir='ltr'>
            <img src='images/logo-WHe.png'class="ml-4" style=' width:40.8%!important'>
            <h1 style="font-weight:900;" class='black-color ml-4'>{{ __('fam-familyFirst')}}</h1>
            <h4 style="font-weight:500; color:#000"class='black-color ml-4'>{{ __('fam-provideAllSecured')}}</h4>
            <h4 style="font-weight:300"  class='black-color ml-4'>{{ __('fam-betterFuture')}}</h4>
            <form class="subscribe_form ml-4 signuptrial" method="post" style="border-radius: 0px 5px 5px 0px;">
                <div class="input-group">
                    <input name="email" class="form-control" id="email" type="email" placeholder="Enter your Email " style='min-width:none !important' title="Your e-mail address is required so I can reply" required="" maxlength="50" pattern="[^@]+@[^@]+\.[a-zA-Z]{2,6}">
                    <input type="hidden" name="type" value="family english">
                    <span class="input-group-btn ">
                            <button class="btn btn-default" style='border-radius: 0px 5px 5px 0px;text-transform: none;' type="submit">{{ __('fam-startNow')}}</button>
                        </span>
                </div>
            </form>
            <div class="form-note ml-5" dir="rtl">
                <p><strong>{{ __('fam-familyMembers')}}</strong> </p>

            </div>

        </div>
        <div class="col-md-6  my-auto " style='display: flex;justify-content: center;'>
            <img src="../Family/images/pngkey.com-family-png-54.png" style="width: 75%;">
        </div>

    </div>
    <div class=" m-0 view-mobile text-left " >
        <div class="container">
            <img src="../Family/images/logo-WHe.png" style="width:85%">
            <h2 style="font-weight:900; color:#000 ;font-size: 2.4rem;margin-top: 0.8rem;" class=''>{{ __('fam-familyFirst')}}</h2>
            <h2 style="font-weight:500 ; max-width: 550;color:#000;margin:0.8rem auto;" >{{ __('fam-weProvideAll')}} <span style="font-weight:700">{{ __('fam-secured')}}</span>{{ __('fam-and')}} <span style="font-weight:700">{{ __('fam-luxurious')}}</span>{{ __('fam-betterFuture2')}} </h2>
            <h5 style="font-weight:300; color:#000" class='my-3'>{{ __('fam-betterFuture')}}</h5>

            <div class="subform my-3">
                <a class="submit"href="https://stickyposts.net/stickypost_register/register-en.php?language=2" style='background: linear-gradient(90deg,#42b0ff,#4262ff);padding: 5px 15px;font-size: 1.5rem ;border-radius:5px'> {{ __('temp-link-1')}}</a>
            </div>
            <div style="margin-top: .6rem;font-size: 1rem; font-weight: 700">
                <a href="https://stickyposts.net/sticky/payment.php" id="compar" style="color:#000; text-decoration: underline;">{{ __('temp-link-2')}} </a>
            </div>
            <div class="form-note" >
                <p style='font-size: 1rem; margin: 0;color:#000'>{{ __('fam-familyMembers')}} </p>
            </div>
        </div>
    </div>
</div>
<div class="client-section">
    <div class="container text-center">
        <div class="clients">
            <div class="single">
                <img src="images/client1.png" class='none' alt="Client" />
                <img src="images/client1-c.png" class="color" alt="Client" />
            </div>
            <div class="single">
                <img src="images/client3.png" class='none' alt="Client" />
                <img src="images/client3-c.png" class="color" alt="Client" />
            </div>
            <div class="single">
                <img src="images/client5.png" class='none' alt="Client" />
                <img src="images/client5-c.png" class="color" alt="Client" />
            </div>
            <div class="single">
                <img src="images/client6.png" class='none' alt="Client" />
                <img src="images/client6-c.png" class="color" alt="Client" />
            </div>
            <div class="single">
                <img src="images/client4.png" class='none' alt="Client" />
                <img src="images/client4-c.png" class="color" alt="Client" />
            </div>
            <div class="single">
                <img src="images/client2.png" class='none' alt="Client" />
                <img src="images/client2-c.png" class="color" alt="Client" />
            </div>
            <div class="single">
                <img src="images/client7.png" class='none' alt="Client" />
                <img src="images/client7-c.png" class="color" alt="Client" />
            </div>
        </div>
    </div>
</div>
<div class='container mt-5 mb-3' >
    <div class="title text-center view-mobile ">
        <h2 style="color:#320b82" >{{ __('fam-whyFamilyPackage')}}</h2>
    </div>
    <div class="box_shadow hide-mobile ">
        <div class="row m-0">
            <div class="col-md-3">
                <img src='../Family/fam.png' alt='family' class='img-fluid'>
            </div>
            <div class="col-md-9" dir="ltr">
                <div class="title text-left">
                    <h2 style="color:#320b82" >{{ __('fam-whyFamilyPackage')}}</h2>
                </div>
                <div class="description">
                    <ul>
                        <li style="font-size: 15px;">{{ __('fam-Why don’t you secure')}} <span class="more">{{ __('fam-learnMore')}}</span></li>
                        <div class="content text-center">
                            <p>{{ __('fam-mediaCelebrities')}}
                            </p>
                            <a class="submit mt-2" href="https://stickyposts.net/stickypost_register/register-en.php?language=2&family=0" style="border-radius: 5px;padding: 2px 10px;color:#fff" >Start Now</a>
                        </div>
                        <li style="font-size: 15px;">{{ __('fam-technologicalSuccess')}} <span class="more">{{ __('fam-learnMore')}}</span></li>
                        <div class="content text-center">
                            <p>
                                {{ __('fam-making money')}}

                            </p>
                            <a class="submit mt-2" href="https://stickyposts.net/stickypost_register/register-en.php?language=2&family=0" style="border-radius: 5px;padding: 2px 10px;color:#fff" >Start Now</a>
                        </div>
                        <li style="font-size: 13px;">{{ __('fam-technologicalDevelopment')}} <span class="more">{{ __('fam-learnMore')}}</span> </li>
                        <div class="content text-center">
                            <p>{{ __('fam-largest monthly')}} </p><br>
                            <a class="my-3" style="color: #fff;text-decoration: underline;font-weight: bold;">{{ __('fam-Click here to download')}}</a><br>
                            <a class="submit mt-2" href="https://stickyposts.net/stickypost_register/register-en.php?language=2&family=0" style="border-radius: 5px;padding: 2px 10px;color:#fff" >Start Now</a>
                        </div>
                    </ul>
                </div>
            </div>

        </div>
    </div>
    <div class="my-4">
        <h3 class="section-head mt-2">{{ __('fam-buildTechnological')}}</h3>
        <h3 class="section-head p-0 mb-3"> {{ __('fam-futureGrandchildren')}}</h3>

        <div class="row mt-3">
            <div class="col-md-4 pt-3">
                <div class="row justify-content-center w-100">
                    <div class="number-circle">1</div>
                </div>
                <div class="box_shadow box_shadow_height mt-2">
                    <h3 style="font-size:1.7rem;">{{ __('fam-social media accounts')}} </h3>
                    <div class="row  my-4">
                        <div class="col-2">
                            <div>
                                <a href="https://twitter.com/StickypostsMEA">
                                    <img src="Twitter.png" class="img-fluid rounded"><br>
                                </a>
                            </div>
                        </div>
                        <div class="col-2">
                            <div>
                                <a href="https://www.facebook.com/stickypoststool">
                                    <img src="Facebook.png" class="img-fluid rounded"><br>
                                </a>
                            </div>
                        </div>
                        <div class="col-2">
                            <div>
                                <a href="https://www.youtube.com/channel/UCU2cHOoahBCDzPHoYGcDdQA?view_as=subscriber">
                                    <img src="YouTube.png" class="img-fluid rounded"><br>
                                </a>
                            </div>
                        </div>
                        <div class="col-2">
                            <div>
                                <a href="https://www.instagram.com/stickypostsmea/">
                                    <img src="Instagram.png" class="img-fluid rounded"><br>
                                </a>
                            </div>
                        </div>
                        <div class="col-2">
                            <div>
                                <a href="https://www.linkedin.com/company/stickypostsmea">
                                    <img src="LinkedIn.png" class="img-fluid rounded"><br>
                                </a>
                            </div>
                        </div>
                        <div class="col-2">
                            <div>
                                <a href="https://www.pinterest.com/stickypostsmea/">
                                    <img src="Pinterest.png" class="img-fluid rounded"><br>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 pt-3">
                <div class="row justify-content-center w-100">
                    <div class="number-circle">2</div>
                </div>
                <div class="box_shadow box_shadow_height mt-2">
                    {{ __('fam-Participate in Sticky posts')}}
                </div>
            </div>
            <div class="col-md-4 pt-3">
                <div class="row justify-content-center w-100">
                    <div class="number-circle">3</div>
                </div>
                <div class="box_shadow box_shadow_height mt-2">
                    {{ __('fam-Start by scheduling')}}
                </div>
            </div>
            <div class="col-md-4 pt-3">
                <div class="row justify-content-center w-100">
                    <div class="number-circle">4</div>
                </div>
                <div class="box_shadow box_shadow_height mt-2">
                    {{ __('fam-Start using the posts generator')}}
                </div>
            </div>
            <div class="col-md-4 pt-3">
                <div class="row justify-content-center w-100">
                    <div class="number-circle">5</div>
                </div>
                <div class="box_shadow box_shadow_height mt-2">
                    {{ __('fam-Receive advertisers')}}
                </div>
            </div>
            <div class="col-md-4 pt-3">
                <div class="row justify-content-center w-100">
                    <div class="number-circle">6</div>
                </div>
                <div class="box_shadow box_shadow_height mt-2">
                    {{ __('fam-Follow activities')}}
                </div>
            </div>
        </div>
    </div>
    <div class="view-mobile  section-2" style="margin:0 !important">
        <div class="row w-75 mx-auto">
            <div class=" col-12">
                <div class="item text-center" dir="ltr">
                    <img src="images/mobile-images/family/Schadule copy.png" class="img-fluid"  style="width:50%">
                    <div class="about" >
                        <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700">{{ __('fam-Automated Scheduling')}}</p>
                        <div class="caption"style="font-size: 1.2rem;line-height: 1.5;">{{ __('fam-Save time by scheduling')}}</div>
                    </div>
                </div>
            </div>
            <div class=" col-12">
                <div class="item text-center" dir="ltr">
                    <img src="images/mobile-images/family/time copy.png" class="img-fluid"  style="width:50%">
                    <div class="about"  >
                        <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700">{{ __('fam-Time Management')}}</p>
                        <div class="caption"style="font-size: 1.2rem;line-height: 1.5;">{{ __('fam-Save your time')}}</div>
                    </div>

                </div>
            </div>
            <div class=" col-12">
                <div class="item text-center" dir="ltr">
                    <img src="images/mobile-images/family/Reports copy.png" class="img-fluid"  style="width:50%">
                    <div class="about"  >
                        <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700">{{ __('fam-reportsStatistics')}}</p>
                        <div class="caption"style="font-size: 1.2rem;line-height: 1.5;">{{ __('fam-Receive detailed')}}</div>
                    </div>
                </div>
            </div>
            <div class=" col-12">
                <div class="item text-center" dir="ltr" style="position:relative;">

                    <img src="images/mobile-images/family/Auto-Reply copy.png" class="img-fluid"  style="width:50%">
                    <div class="about"  >
                        <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700">{{ __('fam-Auto Activities')}}</p>
                        <div class="caption"style="font-size: 1.2rem;line-height: 1.5;">{{ __('fam-Save time by using auto activities')}}</div>
                    </div>

                </div>
            </div>
            <div class=" col-12">
                <div class="item text-center" dir="ltr" style="position:relative;">
                    <!-- Start Tommorow from here -->
                    <img src="images/mobile-images/family/Competitors copy.png" class="img-fluid"  style="width:50%">
                    <div class="about"  >
                        <p style="margin: 0;padding: 0 3px;font-size: 1.5rem;font-weight:700">{{ __('fam-Competitors')}} &amp;{{ __('fam-influencers')}}</p>
                        <div class="caption"style="font-size: 1.2rem;line-height: 1.5;">{{ __('fam-Stay updated')}}</div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="">
        <h1 class='section-head hide-mobile mt-2'>{{ __('fam-Family benefits')}}</h1>
        <h2 class="section-head view-mobile mb-4" >{{ __('fam-FREE E-book')}}</h2>
        <div class="row">
            <div class="col-sm-6 col-md-7 col-lg-9 hide-mobile">
                <div id="features" class="section wb p-0">
                    <div class="container">

                        <div id="default" class="row clearfix zenith_slider p-0">

                            <!--The First row-->
                            <div class="col-lg-4 col-md-8 col-sm-12 col-xs-12 left-row">
                                <ul class="features-left">
                                    <li class="highlight lhgh" data-index="0">
                                        <img src="../Family/images/secure.png">
                                        <div class="fl-inner">
                                            <h4>{{ __('fam-Safe and protected')}}</h4>
                                            <p>{{ __('fam-confidential and protected')}}</p>
                                        </div>
                                    </li><!-- .highlight .left-row -->

                                    <li class="highlight lhgh" data-index="1">
                                        <img src="../Family/images/mobileslider/Time.png">
                                        <div class="fl-inner">
                                            <h4>{{ __('fam-Time saving')}}</h4>
                                            <p>{{ __('fam-Spend 10-20 minutes')}}</p>
                                        </div>
                                    </li><!-- .highlight .left-row -->

                                    <li class="highlight lhgh" data-index="2">
                                        <img src="../Family/images/mobileslider/Reports.png">
                                        <div class="fl-inner">
                                            <h4>{{ __('fam-Reports and statistics')}}</h4>
                                            <p>{{ __('fam-Get detailed')}}</p>
                                        </div>
                                    </li><!-- .highlight .left-row -->
                                </ul>
                            </div><!-- .row .left-row -->

                            <div class="highlights-phone col-lg-4 col-md-4 col-sm-12 col-xs-12 wht">

                                <div class="phone-holder">
                                    <div id="fon"></div>
                                    <div class="hgh-linner hgi" data-index="0">
                                        <img width="190" height="320" src="../Family/images/mobileslider/phone/Secure.png" class="attachment-highlight wp-post-image" alt="screen" />
                                    </div>
                                    <div class="hgh-linner hgi" data-index="1">
                                        <img width="234" height="398" src="../Family/images/mobileslider/phone/time.png" class="attachment-highlight wp-post-image" alt="screensdst" />
                                    </div>
                                    <div class="hgh-linner hgi" data-index="2">
                                        <img width="234" height="398" src="../Family/images/mobileslider/phone/reports.png" class="attachment-highlight wp-post-image" alt="screen_09" />
                                    </div>
                                    <div class="hgh-rinner hgi" data-index="3">
                                        <img width="234" height="398" src="../Family/images/mobileslider/phone/schadule.png" class="attachment-highlight wp-post-image" alt="screen_07" />
                                    </div>
                                    <div class="hgh-rinner hgi" data-index="4">
                                        <img width="234" height="398" src="../Family/images/mobileslider/phone/Auto-reply.png" class="attachment-highlight wp-post-image" alt="screen_08" />
                                    </div>
                                    <div class="hgh-rinner hgi" data-index="5">
                                        <img width="234" height="398" src="../Family/images/mobileslider/phone/competitors.png" class="attachment-highlight wp-post-image" alt="screen_06" />
                                    </div>
                                </div>
                            </div>

                            <!--The Second row-->
                            <div class="col-lg-4 col-md-8 col-sm-12 col-xs-12 right-row">
                                <ul class="features-right">
                                    <li class="highlight rhgh" data-index="3">
                                        <img src="../Family/images/mobileslider/Schadule.png">
                                        <div class="fr-inner">
                                            <h4>{{ __('fam-Auto Scheduling')}}</h4>
                                            <p>{{ __('fam-Post on all')}}</p>
                                        </div>
                                    </li><!-- .highlight .left-row -->
                                    <li class="highlight rhgh" data-index="4">
                                        <img src="../Family/images/mobileslider/Auto-Reply.png">
                                        <div class="fr-inner">
                                            <h4>{{ __('fam-Auto Activities')}}</h4>
                                            <p>{{ __('fam-You can manage')}}</p>
                                        </div>
                                    </li><!-- .highlight .left-row -->
                                    <li class="highlight rhgh" data-index="5">
                                        <img src="../Family/images/mobileslider/Influencer.png">
                                        <div class="fr-inner">
                                            <h4>{{ __('fam-Bloggers and influencers')}}</h4>
                                            <p> {{ __('fam-Stay up to date with influencers')}}</p>
                                        </div>
                                    </li><!-- .highlight .left-row -->
                                </ul>
                            </div><!-- .row .left-row -->

                        </div><!--Highlights close-->
                    </div><!-- end container -->
                </div><!-- end section -->

            </div>
            <div class="col-sm-6 col-md-5 col-lg-3 my-auto">
                <?php include "includes/pdfdownload.php" ?>
            </div>

        </div>
    </div>
    <div class=' text-center hide-mobile' style="width: 100%;overflow: hidden;border-top: 3px solid #320b82 !important;">
        <h2 class="section-head hide-mobile">{{ __('fam-Family Package Prices')}}</h2>
        <div class="row" style="justify-content: center;align-items: center;" dir='ltr'>
            <div class="col-lg-3 col-md-4 col-sm-5 text-center mb-3">
                <div class="single-pricing-one" style="width: 100%;height: 430px;">
                    <div class="top-block" style="direction: ltr;">
                        <h2 style='background: #f8f900;'>{{ __('fam-Monthly')}}</h2>
                        <p class="price m-0" style="direction: rtl;"><?php if ($location == 'Egypt' ){echo '310 EGP';}elseif ($location == 'United Arab Emirates'){echo '73 Dirham';}
                            elseif ($location == 'Saudi Arabia'){echo '75 Riyal';}
                            else {echo '24$';} ?></P>

                        <p class="pack-name"> {{ __('fam-4 Users')}} </p>
                        <div class="line"></div><!-- /.line -->
                    </div><!-- /.top-block -->
                    <ul class="feature-lists text-left px-2" style="direction: ltr;">
                        <li><span style="color:#f00">*</span>{{ __('fam-You can manage')}} <span style="font-weight:bold;font-size:16px">{{ __('fam-number24')}}</span>{{ __('fam-pages only')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Unlimited team members')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Posts Generator')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Up to 50 Megabyte available storage')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Copyright protection')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Reports')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Auto Activities')}} <span style="padding:5px;color:#f00">{{ __('fam-extra')}} </span></li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Availability')}} </li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Competitors')}}</li>
                    </ul><!-- /.feature-lists text-left -->
                    <div class="">
                        <a href="https://stickyposts.net/stickypost_register/register-en.php?language=2&family=0" class="price-btn" style="cursor: pointer;">{{ __('fam-Buy Now')}}</a>
                        <h5 class="tag-line text-center" style="color:#310150;background: #eee;padding: 10px;">{{ __('fam-No Extra')}}</h5>
                    </div><!-- /.bottom-block -->
                    <div style="background-color: #fff;color: #f00;border-top: 2px solid #999;font-weight: bold;width: 80%;margin: auto;">
                        <p style="margin:0">{{ __('fam-Extra Free Trial')}}</p>
                    </div>
                </div><!-- /.single-pricing-one -->
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-3 col-md-4 col-sm-5 text-center mb-3">
                <div class="single-pricing-one" style="width: 100%;height: 430px;">
                    <div class="top-block" style="direction: ltr;">
                        <h2 style='background: #f8f900;'>
                            {{ __('fam-Annually')}}
                        </h2>
                        <p class="price m-0" style="direction: rtl;"><?php if ($location == 'Egypt' ){echo '3340 EGP';}elseif ($location == 'United Arab Emirates'){echo '779 Dirham';}
                            elseif ($location == 'Saudi Arabia'){echo '802 Riyal';}
                            else {echo '213$';} ?></P>

                        <p class="pack-name">{{ __('fam-4 Users')}} </p>
                        <div class="line"></div><!-- /.line -->
                    </div><!-- /.top-block -->
                    <ul class="feature-lists text-left px-2" style="direction: ltr;">
                        <li><span style="color:#f00">*</span>{{ __('fam-You can manage')}}<span style="font-weight:bold;font-size:16px">{{ __('fam-number24')}}</span>{{ __('fam-pages only')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Unlimited team members')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Posts Generator')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Up to 50 Megabyte available storage')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Copyright protection')}}</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Reports')}}Reports</li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Auto Activities')}} <span style="padding:5px;color:#f00">{{ __('fam-extra')}} </span></li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Availability')}} </li>
                        <li><span style="color:#f00">*</span>{{ __('fam-Competitors')}}</li>
                    </ul><!-- /.feature-lists text-left -->
                    <div class="">
                        <a href="https://stickyposts.net/stickypost_register/register-en.php?language=2&family=0" class="price-btn" style="cursor: pointer;"> Buy Now</a>
                        <h5 class="tag-line text-center" style="color:#310150;background: #eee;padding: 10px;">{{ __('fam-No Extra')}}</h5>
                    </div><!-- /.bottom-block -->
                    <div style="background-color: #fff;color: #f00;border-top: 2px solid #999;font-weight: bold;width: 80%;margin: auto;">
                        <p style="margin:0">{{ __('fam-Extra Free Trial')}}</p>
                    </div>
                </div><!-- /.single-pricing-one -->
            </div><!-- /.col-lg-4 -->
        </div>
    </div>
</div>
<?php include "includes/footer-en.php" ?>
<?php include "includes/foot-en.php" ?>
<?php include "includepopsEn.php" ?>
<script>
    //   start Free trial
    $("#alerts").hide();
    //   $('.signuptrialfamily').submit(function(e){
    //   $('#alert').html('loading .........');
    //     $("#alerts").show();
    //     e.preventDefault();

    //     $.ajax({

    //       url:    'freeTrialfamilyEn.php',
    //       method:   'POST',
    //       dataType:   'text',
    //       data:   $(this).serialize() ,
    //       success : function(response)
    //          {
    //              if(response == 1)
    //                 {//window.location.href = 'https://stickyposts.net/stickypost_register/register-en.php?language=2';
    //                     alert('Registration successful, please verify in the registered Email');
    //                 $('#alerts').hide(6000);
    //                 }
    //              else{
    //                 $('#alert').html('This email was used before. Please use another one ');
    //                  $('#alerts').hide(6000);
    //              }
    //          }
    //     });
    //   });
    // end Free trial

    $(".content").slideUp();
    $(".more").click(function(){
        $(this).parent().next().slideToggle(500);
    })
    $("#nav-btn").click(function(){
        $("#main-nav-bar").show("slow");
        $("#nav-btn").hide();
        $("#close-nav-btn").show();
    });
    $("#close-nav-btn").click(function(){
        $("#main-nav-bar").hide("slow");
        $("#nav-btn").show();
        $("#close-nav-btn").hide();
    });

    function lang1() {
        window.location.assign("FamilyAR.php"+ lang_url_params)
    }
    function lang2() {
        window.location.assign("Family-Fr.php"+ lang_url_params)
    }
</script>
</body>
</html>
